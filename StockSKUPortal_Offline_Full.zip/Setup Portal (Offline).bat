@echo off
title Stock SKU Portal - Offline Setup
cd /d "%~dp0"

echo ============================================
echo   Stock SKU Portal - OFFLINE Setup
echo   (installs from the bundled "wheelhouse")
echo ============================================
echo.

REM Check Python is installed and on PATH
python --version >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python was not found.
  echo Install Python 3.14 (64-bit) - the SAME version this bundle was built for.
  echo During install, TICK "Add python.exe to PATH", then run this file again.
  echo.
  pause
  exit /b 1
)

echo Python found:
python --version
echo.

if not exist "wheelhouse" (
  echo [ERROR] The "wheelhouse" folder is missing next to this script.
  echo Make sure you copied the whole folder, including "wheelhouse".
  echo.
  pause
  exit /b 1
)

cd backend

REM Create the virtual environment if it does not already exist
if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  python -m venv .venv
) else (
  echo Virtual environment already exists - reusing it.
)
echo.

echo Installing dependencies from local wheelhouse (no internet required)...
.venv\Scripts\python.exe -m pip install --no-index --find-links "..\wheelhouse" -r requirements.txt

echo.
echo ============================================
echo   Offline setup complete!
echo ============================================
echo.
echo Start the portal by double-clicking "Start Portal.bat".
echo.
pause
