const API_BASE = "http://127.0.0.1:8000/api";
const el = (id) => document.getElementById(id);
const state = {
  companyId: Number(localStorage.getItem("selectedCompanyId")) || null,
  companies: [],
  outlets: [],
  skus: [],
  showProfit: false,
  orderDraft: [],
};
const MASK = "\u2022\u2022\u2022\u2022";

const COMPANY_LOGOS = { shyam: "assets/shyam-logo.png" };

const companySelect = el("company-select");
const tableBody = document.querySelector("#outlet-table tbody");
const statsBox = el("stats");
const listMsg = el("list-msg");

function money(n) {
  return "\u20b9" + Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function fmtDate(s) {
  if (!s) return "";
  const d = new Date(s);
  return isNaN(d) ? "" : d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}
function setListMsg(text, type = "") {
  listMsg.textContent = text;
  listMsg.className = "msg" + (type ? " " + type : "");
}
async function api(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, options);
  if (!res.ok && res.status !== 204) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `HTTP ${res.status}`);
  }
  return res.status === 204 ? null : res.json();
}
function openModal(id) { el(id).classList.remove("hidden"); }
function closeModals() { document.querySelectorAll(".modal").forEach((m) => m.classList.add("hidden")); }

function renderLogo() {
  const logo = el("company-logo");
  const c = state.companies.find((x) => x.id === state.companyId);
  const src = c ? COMPANY_LOGOS[c.name.trim().toLowerCase()] : null;
  if (src) { logo.src = src; logo.classList.remove("hidden"); }
  else { logo.classList.add("hidden"); logo.removeAttribute("src"); }
}

async function loadCompanies() {
  try {
    state.companies = await api("/companies");
  } catch (err) {
    setListMsg("Failed to reach API: " + err.message + ". Is the server running?", "error");
    return;
  }
  if (!state.companies.length) {
    companySelect.innerHTML = `<option value="">No companies</option>`;
    setListMsg("No companies yet. Create one on the Inventory page first.");
    return;
  }
  companySelect.innerHTML = state.companies.map((c) => `<option value="${c.id}">${c.name}</option>`).join("");
  if (!state.companyId || !state.companies.some((c) => c.id === state.companyId)) {
    state.companyId = state.companies[0].id;
  }
  localStorage.setItem("selectedCompanyId", state.companyId);
  companySelect.value = state.companyId;
  renderLogo();
  await loadOutlets();
}

async function loadOutlets() {
  if (!state.companyId) return;
  try {
    state.outlets = await api(`/companies/${state.companyId}/outlets`);
    renderTable();
    renderStats();
    setListMsg("");
  } catch (err) {
    setListMsg("Failed to load outlets: " + err.message, "error");
  }
}

function profitText(value) {
  return state.showProfit ? money(value) : MASK;
}

function renderStats() {
  const totalPending = state.outlets.reduce((a, o) => a + o.total_pending, 0);
  const totalProducts = state.outlets.reduce((a, o) => a + o.total_products, 0);
  const totalAmount = state.outlets.reduce((a, o) => a + o.total_amount, 0);
  const totalProfit = state.outlets.reduce((a, o) => a + (o.total_profit || 0), 0);
  statsBox.innerHTML = `
    <div class="stat"><span class="stat-num">${state.outlets.length}</span><span class="stat-label">Outlets</span></div>
    <div class="stat"><span class="stat-num">${totalProducts}</span><span class="stat-label">Products dispatched</span></div>
    <div class="stat ${totalPending > 0 ? "warn" : ""}"><span class="stat-num">${money(totalPending)}</span><span class="stat-label">Total pending</span></div>
    <div class="stat profit"><span class="stat-num">${profitText(totalProfit)}</span><span class="stat-label">Realized profit</span></div>`;
}

function renderTable() {
  if (!state.outlets.length) {
    tableBody.innerHTML = `<tr><td colspan="10" class="empty">No outlets yet. Click \u201c+ Add Outlet\u201d.</td></tr>`;
    return;
  }

  const term = el("search").value.trim().toLowerCase();
  const filtered = term
    ? state.outlets.filter((o) =>
        [o.name, o.location, o.phone].some((v) => (v || "").toLowerCase().includes(term)))
    : state.outlets;

  if (!filtered.length) {
    tableBody.innerHTML = `<tr><td colspan="10" class="empty">No outlets match \u201c${term}\u201d.</td></tr>`;
    return;
  }

  // Group outlets by place (location); keep names sorted within each place
  const groups = new Map();
  for (const o of filtered) {
    const place = (o.location && o.location.trim()) || "Unassigned";
    if (!groups.has(place)) groups.set(place, []);
    groups.get(place).push(o);
  }
  const places = [...groups.keys()].sort((a, b) => a.localeCompare(b));

  const outletRow = (o) => `
    <tr class="${o.total_pending > 0 ? "row-warn" : ""}">
      <td><strong>${o.name}</strong></td>
      <td>${o.phone ?? ""}</td>
      <td>${o.location ?? ""}</td>
      <td class="num">${o.total_products}</td>
      <td class="num">${money(o.total_amount)}</td>
      <td class="num">${money(o.total_paid)}</td>
      <td class="num"><strong>${money(o.total_pending)}</strong></td>
      <td class="num profit-col">${profitText(o.total_profit || 0)}</td>
      <td>${fmtDate(o.last_updated) || "\u2014"}</td>
      <td class="row-actions">
        <button class="link" data-view="${o.id}">View / Dispatch</button>
        <button class="link" data-edit="${o.id}">Edit</button>
        <button class="link danger" data-delete="${o.id}">Delete</button>
      </td>
    </tr>`;

  tableBody.innerHTML = places.map((place) => {
    const rows = groups.get(place).sort((a, b) => a.name.localeCompare(b.name));
    const products = rows.reduce((a, o) => a + o.total_products, 0);
    const pending = rows.reduce((a, o) => a + o.total_pending, 0);
    const profit = rows.reduce((a, o) => a + (o.total_profit || 0), 0);
    const header = `
      <tr class="group-row">
        <td colspan="3">${place} <span class="group-count">${rows.length}</span></td>
        <td class="num">${products}</td>
        <td colspan="2"></td>
        <td class="num"><strong>${money(pending)}</strong></td>
        <td class="num profit-col">${profitText(profit)}</td>
        <td colspan="2"></td>
      </tr>`;
    return header + rows.map(outletRow).join("");
  }).join("");
}

/* ---------- Add / edit outlet ---------- */
el("add-outlet-btn").addEventListener("click", () => {
  if (!state.companyId) return setListMsg("Select a company first.", "error");
  el("outlet-form").reset();
  el("outlet-edit-id").value = "";
  el("outlet-modal-title").textContent = "Add Retail Outlet";
  el("outlet-msg").textContent = "";
  openModal("outlet-modal");
});

function openOutletEdit(outletId) {
  const o = state.outlets.find((x) => x.id === outletId);
  if (!o) return;
  el("outlet-form").reset();
  el("outlet-edit-id").value = o.id;
  el("outlet-modal-title").textContent = "Edit Retail Outlet";
  el("outlet-name").value = o.name;
  el("outlet-phone").value = o.phone ?? "";
  el("outlet-location").value = o.location ?? "";
  el("outlet-msg").textContent = "";
  openModal("outlet-modal");
}

el("outlet-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const editId = el("outlet-edit-id").value;
  const body = {
    name: el("outlet-name").value.trim(),
    phone: el("outlet-phone").value.trim() || null,
    location: el("outlet-location").value.trim() || null,
  };
  try {
    if (editId) {
      await api(`/outlets/${editId}`, {
        method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
      });
    } else {
      await api(`/companies/${state.companyId}/outlets`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
      });
    }
    closeModals();
    await loadOutlets();
  } catch (err) {
    el("outlet-msg").textContent = err.message;
    el("outlet-msg").className = "msg error";
  }
});

/* ---------- Outlet detail (dispatches) ---------- */
async function openDetail(outletId) {
  const [detail, skus] = await Promise.all([
    api(`/outlets/${outletId}`),
    api(`/skus?company_id=${state.companyId}`),
  ]);
  state.skus = skus;
  el("dispatch-outlet-id").value = outletId;
  el("detail-title").textContent = detail.name + (detail.location ? ` \u2014 ${detail.location}` : "");
  el("detail-summary").innerHTML = `
    <span class="chip"><b>${detail.total_products}</b> products taken</span>
    <span class="chip"><b>${money(detail.total_amount)}</b> total</span>
    <span class="chip"><b>${money(detail.total_paid)}</b> paid</span>
    <span class="chip ${detail.total_pending > 0 ? "chip-warn" : ""}"><b>${money(detail.total_pending)}</b> pending</span>
    <span class="chip chip-profit"><b>${profitText(detail.total_profit || 0)}</b> profit</span>`;

  el("dispatch-sku").innerHTML = skus
    .map((s) => `<option value="${s.id}" data-price="${s.selling_price > 0 ? s.selling_price : s.mrp}">${s.name}${s.variant ? " - " + s.variant : ""} (stock: ${s.quantity_on_hand})</option>`)
    .join("");
  el("dispatch-form").reset();
  el("dispatch-outlet-id").value = outletId;
  el("dispatch-qty").value = 1;
  el("dispatch-paid").value = 0;
  el("dispatch-msg").textContent = "";
  syncDispatchPrice();
  state.orderDraft = [];
  renderOrderLines();
  renderDispatches(detail.dispatches);
  renderPayments(detail.payments || []);
  el("record-payment-btn").dataset.pending = detail.total_pending;
  openModal("detail-modal");
}

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function renderPayments(payments) {
  const body = document.querySelector("#payment-table tbody");
  if (!payments.length) {
    body.innerHTML = `<tr><td colspan="3" class="empty">No payments recorded yet.</td></tr>`;
    return;
  }
  body.innerHTML = payments.map((p) => `
    <tr>
      <td>${fmtDate(p.paid_on || p.created_at)}</td>
      <td class="num"><strong>${money(p.amount)}</strong></td>
      <td>${p.note ? p.note : ""}</td>
    </tr>`).join("");
}

el("record-payment-btn").addEventListener("click", () => {
  const outletId = Number(el("dispatch-outlet-id").value);
  if (!outletId) return;
  const outlet = state.outlets.find((o) => o.id === outletId);
  el("payment-form").reset();
  el("payment-outlet-id").value = outletId;
  el("payment-date").value = todayStr();
  const pending = Number(el("record-payment-btn").dataset.pending || 0);
  el("payment-outlet-label").textContent =
    (outlet ? outlet.name : "Outlet") + ` \u2014 pending: ${money(pending)}`;
  el("payment-msg").textContent = "";
  openModal("payment-modal");
});

el("payment-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const outletId = Number(el("payment-outlet-id").value);
  const amount = Number(el("payment-amount").value);
  if (!(amount > 0)) { setPaymentMsg("Enter an amount greater than 0.", "error"); return; }
  const body = {
    amount,
    paid_on: el("payment-date").value || null,
    note: el("payment-note").value.trim() || null,
  };
  try {
    const r = await api(`/outlets/${outletId}/payment`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });
    closeModals();
    if (r.leftover > 0) {
      alert(`Recorded ${money(r.allocated)}. This outlet is now fully paid; ${money(r.leftover)} was more than the pending balance and was not applied.`);
    }
    await openDetail(outletId);
    await loadOutlets();
  } catch (err) { setPaymentMsg("Payment failed: " + err.message, "error"); }
});

function setPaymentMsg(text, type = "") {
  el("payment-msg").textContent = text;
  el("payment-msg").className = "msg" + (type ? " " + type : "");
}

el("print-bill-btn").addEventListener("click", () => {
  const outletId = Number(el("dispatch-outlet-id").value);
  if (!outletId) return;
  const outlet = state.outlets.find((o) => o.id === outletId);
  el("bill-outlet-id").value = outletId;
  el("bill-outlet-label").textContent = outlet ? outlet.name + (outlet.location ? ` \u2014 ${outlet.location}` : "") : "";
  el("bill-scope").value = "all";
  const t = todayStr();
  el("bill-date").value = t;
  el("bill-from").value = t;
  el("bill-to").value = t;
  syncBillFields();
  openModal("bill-modal");
});

function syncBillFields() {
  const scope = el("bill-scope").value;
  el("bill-date-label").style.display = scope === "day" ? "" : "none";
  el("bill-from-label").style.display = scope === "range" ? "" : "none";
  el("bill-to-label").style.display = scope === "range" ? "" : "none";
}
el("bill-scope").addEventListener("change", syncBillFields);

el("open-bill-btn").addEventListener("click", () => {
  const outletId = Number(el("bill-outlet-id").value);
  if (!outletId) return;
  const scope = el("bill-scope").value;
  const q = new URLSearchParams({ outlet_id: outletId });
  if (scope === "day") {
    const d = el("bill-date").value;
    if (!d) return alert("Pick a date.");
    q.set("from", d);
    q.set("to", d);
  } else if (scope === "range") {
    const from = el("bill-from").value;
    const to = el("bill-to").value;
    if (!from || !to) return alert("Pick both From and To dates.");
    if (from > to) return alert("From date must be on or before To date.");
    q.set("from", from);
    q.set("to", to);
  }
  window.open(`bill.html?${q.toString()}`, "_blank");
  closeModals();
});

function syncDispatchPrice() {
  const opt = el("dispatch-sku").selectedOptions[0];
  if (opt && !el("dispatch-price").value) el("dispatch-price").value = opt.dataset.price;
}
el("dispatch-sku").addEventListener("change", () => {
  const opt = el("dispatch-sku").selectedOptions[0];
  if (opt) el("dispatch-price").value = opt.dataset.price;
});

/* ---------- Multi-item order builder ---------- */
function renderOrderLines() {
  const wrap = el("order-lines-wrap");
  const body = document.querySelector("#order-lines-table tbody");
  if (!state.orderDraft.length) {
    wrap.style.display = "none";
    body.innerHTML = "";
    el("order-total").textContent = money(0);
    el("dispatch-submit").textContent = "Dispatch Order (Stock Out)";
    return;
  }
  wrap.style.display = "";
  body.innerHTML = state.orderDraft.map((line, idx) => `
    <tr>
      <td>${line.name}</td>
      <td>${line.variant ?? ""}</td>
      <td class="num">${line.quantity}</td>
      <td class="num">${money(line.unit_price)}</td>
      <td class="num">${money(line.unit_price * line.quantity)}</td>
      <td class="row-actions"><button type="button" class="link danger" data-remove-line="${idx}">Remove</button></td>
    </tr>`).join("");
  const total = state.orderDraft.reduce((a, l) => a + l.unit_price * l.quantity, 0);
  el("order-total").textContent = money(total);
  const count = state.orderDraft.reduce((a, l) => a + l.quantity, 0);
  el("dispatch-submit").textContent = `Dispatch Order \u2014 ${state.orderDraft.length} item(s), ${count} unit(s)`;
}

function addOrderLine() {
  const opt = el("dispatch-sku").selectedOptions[0];
  if (!opt) { setDispatchMsg("Select a product first.", "error"); return; }
  const skuId = Number(el("dispatch-sku").value);
  const quantity = Number(el("dispatch-qty").value);
  if (!Number.isInteger(quantity) || quantity <= 0) { setDispatchMsg("Enter a whole quantity greater than 0.", "error"); return; }
  const priceRaw = el("dispatch-price").value;
  const sku = state.skus.find((s) => s.id === skuId);
  const defaultPrice = sku ? (sku.selling_price > 0 ? sku.selling_price : sku.mrp) : 0;
  const unit_price = priceRaw === "" ? defaultPrice : Number(priceRaw);

  // Combine with an existing draft line for the same SKU + price
  const existing = state.orderDraft.find((l) => l.sku_id === skuId && l.unit_price === unit_price);
  const already = state.orderDraft.filter((l) => l.sku_id === skuId).reduce((a, l) => a + l.quantity, 0);
  if (sku && already + quantity > sku.quantity_on_hand) {
    setDispatchMsg(`Only ${sku.quantity_on_hand} in stock for ${sku.name}${sku.variant ? " - " + sku.variant : ""} (already ${already} in this order).`, "error");
    return;
  }
  if (existing) existing.quantity += quantity;
  else state.orderDraft.push({ sku_id: skuId, name: sku ? sku.name : opt.textContent, variant: sku ? sku.variant : null, quantity, unit_price });

  setDispatchMsg("");
  el("dispatch-qty").value = 1;
  renderOrderLines();
}

function setDispatchMsg(text, type = "") {
  el("dispatch-msg").textContent = text;
  el("dispatch-msg").className = "msg" + (type ? " " + type : "");
}

el("add-line-btn").addEventListener("click", addOrderLine);
document.querySelector("#order-lines-table tbody").addEventListener("click", (e) => {
  const idx = e.target.dataset.removeLine;
  if (idx === undefined) return;
  state.orderDraft.splice(Number(idx), 1);
  renderOrderLines();
});

function renderDispatches(dispatches) {
  const body = document.querySelector("#dispatch-table tbody");
  if (!dispatches.length) {
    body.innerHTML = `<tr><td colspan="10" class="empty">No items dispatched yet.</td></tr>`;
    return;
  }
  body.innerHTML = dispatches.map((d) => `
    <tr class="${d.pending_amount > 0 ? "row-warn" : ""}">
      <td>${d.item_name}${d.note ? `<div class="cell-note">${d.note}</div>` : ""}</td>
      <td>${d.variant ?? ""}</td>
      <td class="num"><strong>${d.quantity}</strong></td>
      <td class="num">${money(d.unit_price)}</td>
      <td class="num">${money(d.total_amount)}</td>
      <td class="num">${money(d.amount_paid)}</td>
      <td class="num"><strong>${money(d.pending_amount)}</strong></td>
      <td class="num profit-col">${profitText(d.profit)}</td>
      <td>${fmtDate(d.created_at)}</td>
      <td class="row-actions">
        <button class="link" data-edit-qty="${d.id}" data-qty="${d.quantity}" data-price="${d.unit_price}">Edit Qty</button>
        ${d.pending_amount > 0 ? `<button class="link in" data-pay="${d.id}" data-pending="${d.pending_amount}">Pay</button>` : ""}
        <button class="link danger" data-del-dispatch="${d.id}">Remove</button>
      </td>
    </tr>`).join("");
}

el("dispatch-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const outletId = el("dispatch-outlet-id").value;

  // If the user filled the top row but didn't click "+ Add item", include it
  if (!state.orderDraft.length && el("dispatch-sku").value) addOrderLine();
  if (!state.orderDraft.length) {
    setDispatchMsg("Add at least one product to the order.", "error");
    return;
  }

  const body = {
    items: state.orderDraft.map((l) => ({ sku_id: l.sku_id, quantity: l.quantity, unit_price: l.unit_price })),
    amount_paid: Number(el("dispatch-paid").value) || 0,
    note: el("dispatch-note").value.trim() || null,
  };
  try {
    await api(`/outlets/${outletId}/orders`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });
    state.orderDraft = [];
    await openDetail(Number(outletId)); // refresh detail
    await loadOutlets(); // refresh summary table behind
  } catch (err) {
    setDispatchMsg(err.message, "error");
  }
});

document.querySelector("#dispatch-table tbody").addEventListener("click", async (e) => {
  const t = e.target;
  const outletId = Number(el("dispatch-outlet-id").value);
  if (t.dataset.pay) {
    const suggested = t.dataset.pending;
    const input = prompt("Payment amount:", suggested);
    if (input === null) return;
    const amount = Number(input);
    if (!(amount > 0)) return;
    try {
      await api(`/dispatches/${t.dataset.pay}/payment`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ amount }),
      });
      await openDetail(outletId);
      await loadOutlets();
    } catch (err) { alert("Payment failed: " + err.message); }
  }
  if (t.dataset.editQty) {
    const input = prompt("New order quantity (inventory stock will adjust by the difference):", t.dataset.qty);
    if (input === null) return;
    const quantity = Number(input);
    if (!Number.isInteger(quantity) || quantity <= 0) { alert("Enter a whole number greater than 0."); return; }
    try {
      await api(`/dispatches/${t.dataset.editQty}`, {
        method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ quantity }),
      });
      await openDetail(outletId);
      await loadOutlets();
    } catch (err) { alert("Update failed: " + err.message); }
  }
  if (t.dataset.delDispatch) {
    if (!confirm("Remove this dispatch and return the quantity to inventory?")) return;
    try {
      await api(`/dispatches/${t.dataset.delDispatch}`, { method: "DELETE" });
      await openDetail(outletId);
      await loadOutlets();
    } catch (err) { alert("Remove failed: " + err.message); }
  }
});

/* ---------- Outlet table actions ---------- */
tableBody.addEventListener("click", async (e) => {
  const t = e.target;
  if (t.dataset.view) return openDetail(Number(t.dataset.view));
  if (t.dataset.edit) return openOutletEdit(Number(t.dataset.edit));
  if (t.dataset.delete) {
    if (!confirm("Delete this outlet and its dispatch history? (Inventory is not restored.)")) return;
    try {
      await api(`/outlets/${t.dataset.delete}`, { method: "DELETE" });
      await loadOutlets();
    } catch (err) { alert("Delete failed: " + err.message); }
  }
});

companySelect.addEventListener("change", async () => {
  state.companyId = Number(companySelect.value);
  localStorage.setItem("selectedCompanyId", state.companyId);
  renderLogo();
  await loadOutlets();
});
/* ---------- Print report ---------- */
el("delete-all-outlets-btn").addEventListener("click", async () => {
  if (!state.companyId) return setListMsg("Select a company first.", "error");
  const company = state.companies.find((c) => c.id === state.companyId);
  const name = company ? company.name : "this company";
  const count = state.outlets.length;
  if (!count) return setListMsg("There are no outlets.", "error");
  const answer = prompt(
    `This will clear ALL order/dispatch & payment records for every outlet in "${name}".\n` +
    `The outlets themselves are KEPT (only their order history is removed).\n` +
    `Inventory stock is NOT added back. This cannot be undone.\n\nType DELETE to confirm:`
  );
  if (answer === null) return;
  if (answer.trim().toUpperCase() !== "DELETE") {
    return setListMsg("Cancelled - confirmation text did not match.", "error");
  }
  try {
    const res = await api(`/companies/${state.companyId}/dispatches`, { method: "DELETE" });
    setListMsg(`Cleared ${res.cleared} order/payment record(s). Outlets kept.`, "success");
    await loadOutlets();
  } catch (err) {
    setListMsg("Clear failed: " + err.message, "error");
  }
});
el("print-report-btn").addEventListener("click", () => {
  if (!state.companyId) return setListMsg("Select a company first.", "error");
  const today = new Date();
  el("print-date").value = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  el("print-outlet").innerHTML = state.outlets
    .map((o) => `<option value="${o.id}">${o.name}${o.location ? " - " + o.location : ""}</option>`)
    .join("");
  syncPrintFields();
  openModal("print-modal");
});
function syncPrintFields() {
  const scope = el("print-scope").value;
  el("print-date-label").style.display = scope === "day" ? "" : "none";
  el("print-outlet-label").style.display = scope === "outlet" ? "" : "none";
}
el("print-scope").addEventListener("change", syncPrintFields);
el("open-print-btn").addEventListener("click", () => {
  const scope = el("print-scope").value;
  const q = new URLSearchParams({ company_id: state.companyId, scope });
  if (scope === "day") q.set("date", el("print-date").value);
  if (scope === "outlet") q.set("outlet_id", el("print-outlet").value);
  window.open(`report.html?${q.toString()}`, "_blank");
  closeModals();
});

el("search").addEventListener("input", renderTable);
el("toggle-profit").addEventListener("click", () => {
  state.showProfit = !state.showProfit;
  el("toggle-profit").textContent = state.showProfit ? "Hide Profit" : "Show Profit";
  el("toggle-profit").classList.toggle("active", state.showProfit);
  renderStats();
  renderTable();
  // Re-render the open detail view if a dispatch table is showing
  const openId = Number(el("dispatch-outlet-id").value);
  if (openId && !el("detail-modal").classList.contains("hidden")) openDetail(openId);
});
document.querySelectorAll("[data-close-modal]").forEach((b) => b.addEventListener("click", closeModals));
document.querySelectorAll(".modal").forEach((m) =>
  m.addEventListener("click", (e) => { if (e.target === m) closeModals(); })
);

loadCompanies();
