from fastapi import APIRouter, Depends, HTTPException, UploadFile, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.company import CompanyCreate, CompanyOut, CompanySummary
from app.schemas.stock_movement import StockLotOut
from app.services import (
    company_service,
    import_export_service,
    lot_service,
    sku_service,
)

router = APIRouter(prefix="/companies", tags=["companies"])


def _get_company_or_404(db: Session, company_id: int):
    company = company_service.get_company(db, company_id)
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")
    return company


@router.get("", response_model=list[CompanySummary])
def list_companies(db: Session = Depends(get_db)):
    return [company_service.summarize(db, c) for c in company_service.list_companies(db)]


@router.post("", response_model=CompanyOut, status_code=status.HTTP_201_CREATED)
def create_company(payload: CompanyCreate, db: Session = Depends(get_db)):
    if company_service.get_company_by_name(db, payload.name):
        raise HTTPException(status_code=409, detail=f"Company '{payload.name}' already exists")
    return company_service.create_company(db, payload.name)


@router.get("/{company_id}", response_model=CompanySummary)
def get_company(company_id: int, db: Session = Depends(get_db)):
    return company_service.summarize(db, _get_company_or_404(db, company_id))


@router.delete("/{company_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_company(company_id: int, db: Session = Depends(get_db)):
    company_service.delete_company(db, _get_company_or_404(db, company_id))


@router.delete("/{company_id}/skus")
def delete_all_skus(company_id: int, db: Session = Depends(get_db)):
    """Delete ALL products for this company (irreversible)."""
    _get_company_or_404(db, company_id)
    deleted = sku_service.delete_all_skus(db, company_id)
    return {"deleted": deleted}


@router.delete("/{company_id}/stock-history")
def clear_stock_history(company_id: int, db: Session = Depends(get_db)):
    """Clear the stock movement history for this company's products,
    keeping the products (and their current quantities) intact."""
    _get_company_or_404(db, company_id)
    cleared = sku_service.clear_stock_history(db, company_id)
    return {"cleared": cleared}


@router.get("/{company_id}/lots", response_model=list[StockLotOut])
def list_lots(company_id: int, search: str | None = None, db: Session = Depends(get_db)):
    """Master lot view: every lot for this company's products with received /
    sold / remaining quantities."""
    _get_company_or_404(db, company_id)
    return lot_service.list_company_lots(db, company_id, search)


@router.post("/{company_id}/reset-stock")
def reset_stock(company_id: int, db: Session = Depends(get_db)):
    """Start fresh: clear all lots + stock history and set On-Hand to 0 for
    every product. Products, prices and MRP are kept."""
    _get_company_or_404(db, company_id)
    return lot_service.reset_stock(db, company_id)


@router.post("/{company_id}/import")
async def import_inventory(company_id: int, file: UploadFile, db: Session = Depends(get_db)):
    company = _get_company_or_404(db, company_id)
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")
    result = import_export_service.import_rows(db, company, file.filename or "upload.csv", content)
    return result


@router.get("/{company_id}/export")
def export_inventory(company_id: int, db: Session = Depends(get_db)):
    company = _get_company_or_404(db, company_id)
    skus = sku_service.list_skus(db, company_id, limit=100000)
    data = import_export_service.export_workbook(db, company, skus)
    safe_name = "".join(c if c.isalnum() else "_" for c in company.name)
    headers = {"Content-Disposition": f'attachment; filename="{safe_name}_inventory.xlsx"'}
    return StreamingResponse(
        iter([data]),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers=headers,
    )
