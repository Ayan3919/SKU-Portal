from datetime import datetime

from fastapi import APIRouter, HTTPException, UploadFile
from fastapi.responses import FileResponse

from app.services import backup_service

router = APIRouter(prefix="/backup", tags=["backup"])


@router.get("")
def list_backups():
    return backup_service.list_backups()


@router.post("")
def create_backup(label: str | None = None):
    try:
        return backup_service.create_backup(label)
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.get("/download")
def download_current():
    """Download a fresh dated snapshot of the current database."""
    try:
        info = backup_service.create_backup()
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    path = backup_service.backup_file_path(info["name"])
    return FileResponse(path, media_type="application/octet-stream", filename=info["name"])


@router.get("/{name}/download")
def download_backup(name: str):
    try:
        path = backup_service.backup_file_path(name)
    except (FileNotFoundError, ValueError):
        raise HTTPException(status_code=404, detail="Backup not found")
    return FileResponse(path, media_type="application/octet-stream", filename=name)


@router.post("/{name}/restore")
def restore_backup(name: str):
    try:
        return backup_service.restore_backup(name)
    except (FileNotFoundError, ValueError):
        raise HTTPException(status_code=404, detail="Backup not found")


@router.post("/restore-upload")
async def restore_upload(file: UploadFile):
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")
    try:
        return backup_service.restore_from_bytes(content)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.delete("/{name}")
def delete_backup(name: str):
    try:
        backup_service.delete_backup(name)
    except (FileNotFoundError, ValueError):
        raise HTTPException(status_code=404, detail="Backup not found")
    return {"deleted": name}
