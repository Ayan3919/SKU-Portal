const API_BASE = "http://127.0.0.1:8000/api";

const el = (id) => document.getElementById(id);
const tableBody = document.querySelector("#backup-table tbody");
const msg = el("msg");

function setMsg(text, type = "") {
  msg.textContent = text;
  msg.className = "msg" + (type ? " " + type : "");
}
function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );
}
function prettyDateTime(d) {
  if (!d) return "";
  const dt = new Date(d);
  return isNaN(dt) ? esc(d) : dt.toLocaleString("en-IN", {
    day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit",
  });
}
async function api(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, options);
  if (!res.ok && res.status !== 204) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `HTTP ${res.status}`);
  }
  return res.status === 204 ? null : res.json();
}

async function loadBackups() {
  try {
    const items = await api("/backup");
    render(items);
  } catch (err) {
    setMsg("Failed to load backups: " + err.message, "error");
  }
}

function render(items) {
  if (!items.length) {
    tableBody.innerHTML = `<tr><td colspan="5" class="empty">No backups yet. Click "Create backup now" to make your first snapshot.</td></tr>`;
    return;
  }
  tableBody.innerHTML = items.map((b) => `
    <tr>
      <td>${prettyDateTime(b.created_at)}</td>
      <td>${b.is_safety
        ? '<span class="badge reorder">Auto (pre-restore)</span>'
        : '<span class="badge ok">Manual</span>'}</td>
      <td><span class="muted-line" style="margin:0;">${esc(b.name)}</span></td>
      <td class="num">${b.size_kb} KB</td>
      <td class="row-actions">
        <button class="link" data-download="${esc(b.name)}">Download</button>
        <button class="link in" data-restore="${esc(b.name)}">Restore</button>
        <button class="link danger" data-delete="${esc(b.name)}">Delete</button>
      </td>
    </tr>`).join("");
}

tableBody.addEventListener("click", async (e) => {
  const t = e.target;
  if (t.dataset.download) {
    window.open(`${API_BASE}/backup/${encodeURIComponent(t.dataset.download)}/download`, "_blank");
    return;
  }
  if (t.dataset.restore) {
    const name = t.dataset.restore;
    const answer = prompt(
      `RESTORE from "${name}"?\n\n` +
      `This replaces ALL current data with the contents of this backup.\n` +
      `A safety snapshot of the current data is taken first.\n\n` +
      `Type RESTORE to confirm:`
    );
    if (answer === null) return;
    if (answer.trim().toUpperCase() !== "RESTORE") return setMsg("Cancelled - confirmation did not match.", "error");
    try {
      const r = await api(`/backup/${encodeURIComponent(name)}/restore`, { method: "POST" });
      setMsg(`Restored from ${name}. A safety copy (${r.safety_backup || "n/a"}) was saved. Reloading...`, "success");
      setTimeout(() => location.reload(), 1500);
      await loadBackups();
    } catch (err) {
      setMsg("Restore failed: " + err.message, "error");
    }
    return;
  }
  if (t.dataset.delete) {
    if (!confirm(`Delete backup "${t.dataset.delete}"? This only removes the backup file, not your live data.`)) return;
    try {
      await api(`/backup/${encodeURIComponent(t.dataset.delete)}`, { method: "DELETE" });
      setMsg("Backup deleted.", "success");
      await loadBackups();
    } catch (err) {
      setMsg("Delete failed: " + err.message, "error");
    }
  }
});

el("create-btn").addEventListener("click", async () => {
  const label = el("backup-label").value.trim();
  setMsg("Creating backup...");
  try {
    const q = label ? `?label=${encodeURIComponent(label)}` : "";
    const b = await api(`/backup${q}`, { method: "POST" });
    el("backup-label").value = "";
    setMsg(`Backup created: ${b.name} (${b.size_kb} KB).`, "success");
    await loadBackups();
  } catch (err) {
    setMsg("Backup failed: " + err.message, "error");
  }
});

el("download-btn").addEventListener("click", () => {
  setMsg("Preparing download...");
  window.open(`${API_BASE}/backup/download`, "_blank");
  setTimeout(loadBackups, 800);
  setMsg("A dated copy is downloading and also saved to this machine.", "success");
});

el("upload-btn").addEventListener("click", () => el("upload-file").click());
el("upload-file").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const answer = prompt(
    `RESTORE from the file "${file.name}"?\n\n` +
    `This replaces ALL current data. A safety snapshot is taken first.\n\n` +
    `Type RESTORE to confirm:`
  );
  if (answer === null || answer.trim().toUpperCase() !== "RESTORE") {
    e.target.value = "";
    return setMsg("Cancelled.", "error");
  }
  const fd = new FormData();
  fd.append("file", file);
  setMsg("Restoring from " + file.name + "...");
  try {
    const r = await api(`/backup/restore-upload`, { method: "POST", body: fd });
    setMsg(`Restored from ${file.name}. Safety copy: ${r.safety_backup || "n/a"}. Reloading...`, "success");
    setTimeout(() => location.reload(), 1500);
  } catch (err) {
    setMsg("Restore failed: " + err.message, "error");
  } finally {
    e.target.value = "";
  }
});

el("refresh-btn").addEventListener("click", loadBackups);

loadBackups();
