const API_BASE = "http://127.0.0.1:8000/api";
const COMPANY_LOGOS = { shyam: "assets/shyam-logo.png" };

const params = new URLSearchParams(location.search);
const outletId = params.get("outlet_id");
const fromDate = params.get("from"); // "YYYY-MM-DD" or null
const toDate = params.get("to");
const sheet = document.getElementById("sheet");

// Calendar date (YYYY-MM-DD) portion of a stored timestamp / date string
function dayOf(s) {
  return String(s || "").slice(0, 10);
}
function inRange(s) {
  if (!fromDate || !toDate) return true;
  const d = dayOf(s);
  return d >= fromDate && d <= toDate;
}

function money(n) {
  return "\u20b9" + Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );
}
function fmtDate(s) {
  if (!s) return "";
  const d = new Date(s);
  return isNaN(d) ? esc(s) : d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}
function fmtDateTime(s) {
  const d = new Date(s || Date.now());
  return d.toLocaleString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

async function load() {
  if (!outletId) {
    sheet.innerHTML = `<p class="empty">No outlet specified.</p>`;
    return;
  }
  let d;
  try {
    const res = await fetch(`${API_BASE}/outlets/${outletId}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    d = await res.json();
  } catch (err) {
    sheet.innerHTML = `<p class="empty">Could not load the bill: ${esc(err.message)}. Is the server running?</p>`;
    return;
  }
  render(d);
}

function render(d) {
  const company = d.company_name || "Stock SKU Portal";
  const logo = COMPANY_LOGOS[(d.company_name || "").trim().toLowerCase()];

  const isPeriod = Boolean(fromDate && toDate);

  // Dispatches chronological (oldest first) for a readable statement, filtered to the period
  const items = [...(d.dispatches || [])]
    .filter((l) => inRange(l.created_at))
    .sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
  const payments = [...(d.payments || [])]
    .filter((p) => inRange(p.paid_on || p.created_at))
    .sort((a, b) => new Date(a.paid_on || a.created_at) - new Date(b.paid_on || b.created_at));

  // Period sub-totals (used when a date filter is applied)
  const periodAmount = items.reduce((a, l) => a + l.total_amount, 0);
  const periodPaid = payments.reduce((a, p) => a + p.amount, 0);

  const periodLabel = isPeriod
    ? (fromDate === toDate ? fmtDate(fromDate) : `${fmtDate(fromDate)} to ${fmtDate(toDate)}`)
    : "";

  const itemRows = items.length
    ? items.map((l, i) => `
      <tr>
        <td class="num">${i + 1}</td>
        <td>${fmtDate(l.created_at)}</td>
        <td>${esc(l.item_name)}${l.note ? `<div class="note-line">${esc(l.note)}</div>` : ""}</td>
        <td>${esc(l.variant ?? "")}</td>
        <td class="num">${l.quantity}</td>
        <td class="num">${money(l.unit_price)}</td>
        <td class="num">${money(l.total_amount)}</td>
      </tr>`).join("")
    : `<tr><td colspan="7" class="empty">No items dispatched${isPeriod ? " in this period" : ""}.</td></tr>`;

  const paymentRows = payments.length
    ? payments.map((p) => `
      <tr>
        <td>${fmtDate(p.paid_on || p.created_at)}</td>
        <td class="num">${money(p.amount)}</td>
        <td>${esc(p.note ?? "")}</td>
      </tr>`).join("")
    : `<tr><td colspan="3" class="empty">No payments recorded${isPeriod ? " in this period" : ""}.</td></tr>`;

  const paymentsSection = `
    <div class="section-h">Payments Received${isPeriod ? ` <span style="font-weight:400;color:var(--muted);">(${esc(periodLabel)})</span>` : ""}</div>
    <table>
      <thead><tr><th>Date</th><th class="num">Amount</th><th>Note</th></tr></thead>
      <tbody>${paymentRows}</tbody>
    </table>`;

  sheet.innerHTML = `
    <div class="bill-header">
      <div class="bill-brand">
        ${logo ? `<img src="${logo}" alt="logo" onerror="this.style.display='none'" />` : ""}
        <div>
          <h1>${esc(company)}</h1>
          <div class="tag">Stock / Dispatch Statement</div>
        </div>
      </div>
      <div class="bill-meta">
        <div class="bill-title">BILL</div>
        <div>Generated: ${fmtDateTime()}</div>
        <div>Bill Ref: OUT-${esc(String(d.id).padStart(4, "0"))}</div>
        ${isPeriod ? `<div><b>Period: ${periodLabel}</b></div>` : ""}
      </div>
    </div>

    <div class="party">
      <div class="box">
        <div class="lbl">Billed To</div>
        <div class="val">${esc(d.name)}</div>
        ${d.location ? `<div>${esc(d.location)}</div>` : ""}
        ${d.phone ? `<div>Ph: ${esc(d.phone)}</div>` : ""}
      </div>
      <div class="box" style="text-align:right;">
        <div class="lbl">Products Taken</div>
        <div class="val">${d.total_products}</div>
      </div>
    </div>

    <div class="section-h">Items Dispatched${isPeriod ? ` <span style="font-weight:400;color:var(--muted);">(${esc(periodLabel)})</span>` : ""}</div>
    <table>
      <thead>
        <tr><th class="num">#</th><th>Date</th><th>Item</th><th>Varient</th><th class="num">Qty</th><th class="num">Unit Price</th><th class="num">Amount</th></tr>
      </thead>
      <tbody>${itemRows}</tbody>
      <tfoot>
        <tr><td colspan="6" class="num">${isPeriod ? "Amount (this period)" : "Total Amount"}</td><td class="num">${money(isPeriod ? periodAmount : d.total_amount)}</td></tr>
      </tfoot>
    </table>

    ${paymentsSection}

    <div class="totals">
      <table>
        ${isPeriod ? `
        <tr><td>Amount (this period)</td><td class="num">${money(periodAmount)}</td></tr>
        <tr><td>Paid (this period)</td><td class="num">${money(periodPaid)}</td></tr>
        <tr class="grand pending"><td>Overall Balance Pending</td><td class="num">${money(d.total_pending)}</td></tr>
        ` : `
        <tr><td>Total Amount</td><td class="num">${money(d.total_amount)}</td></tr>
        <tr><td>Total Paid</td><td class="num">${money(d.total_paid)}</td></tr>
        <tr class="grand pending"><td>Balance Pending</td><td class="num">${money(d.total_pending)}</td></tr>
        `}
      </table>
    </div>

    <div class="bill-foot">
      <div>This is a computer-generated statement.</div>
      <div class="sign">Authorised Signatory</div>
    </div>`;

  document.title = `Bill - ${d.name}`;
}

load();
