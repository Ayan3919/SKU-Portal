/* Shared auth guard. Include on every protected page BEFORE its page script. */
(function () {
  const AUTH_API_BASE = "http://127.0.0.1:8000/api";
  const token = localStorage.getItem("authToken");

  // No token -> straight to the login screen.
  if (!token) {
    location.replace("login.html");
    return;
  }

  // Apply role immediately so cost/profit stays hidden for staff before render.
  const role = localStorage.getItem("authRole") || "staff";
  document.documentElement.classList.add("role-" + role);

  // Header for API calls elsewhere.
  window.authHeaders = function () {
    const t = localStorage.getItem("authToken");
    return t ? { Authorization: "Bearer " + t } : {};
  };

  window.logout = async function () {
    try {
      await fetch(`${AUTH_API_BASE}/auth/logout`, { method: "POST", headers: window.authHeaders() });
    } catch (_) { /* ignore network errors on logout */ }
    localStorage.removeItem("authToken");
    localStorage.removeItem("authRole");
    localStorage.removeItem("authName");
    location.replace("login.html");
  };

  // Verify the token is still valid and refresh role/name.
  fetch(`${AUTH_API_BASE}/auth/me`, { headers: window.authHeaders() })
    .then((res) => {
      if (res.status === 401) throw new Error("expired");
      return res.json();
    })
    .then((me) => {
      localStorage.setItem("authRole", me.role);
      localStorage.setItem("authName", me.display_name || me.username);
      if (!document.documentElement.classList.contains("role-" + me.role)) {
        document.documentElement.classList.add("role-" + me.role);
      }
    })
    .catch((err) => {
      if (err && err.message === "expired") {
        localStorage.removeItem("authToken");
        location.replace("login.html");
      }
    });

  // Inject a user badge + logout button into the nav once the DOM is ready.
  document.addEventListener("DOMContentLoaded", () => {
    const nav = document.querySelector(".app-nav");
    if (!nav) return;
    const name = localStorage.getItem("authName") || "User";
    const roleLabel = (localStorage.getItem("authRole") || "").toUpperCase();
    const box = document.createElement("div");
    box.className = "user-box";
    box.innerHTML = `<span class="user-name">${name}${roleLabel ? ` <span class="user-role">${roleLabel}</span>` : ""}</span>
      <button type="button" id="logout-btn" class="logout-btn">Logout</button>`;
    nav.appendChild(box);
    document.getElementById("logout-btn").addEventListener("click", window.logout);
  });
})();
