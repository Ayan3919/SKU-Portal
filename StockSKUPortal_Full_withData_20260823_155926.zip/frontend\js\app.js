const API_BASE = "http://127.0.0.1:8000/api";

const el = (id) => document.getElementById(id);
const state = { companyId: null, companies: [], skus: [], showProfit: false };
const MASK = "\u2022\u2022\u2022\u2022";

const savedCompanyId = Number(localStorage.getItem("selectedCompanyId")) || null;
if (savedCompanyId) state.companyId = savedCompanyId;

const companySelect = el("company-select");
const tableBody = document.querySelector("#sku-table tbody");
const statsBox = el("stats");
const listMsg = el("list-msg");

function money(n) {
  return "\u20b9" + Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function setListMsg(text, type = "") {
  listMsg.textContent = text;
  listMsg.className = "msg" + (type ? " " + type : "");
}
async function api(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, options);
  if (!res.ok && res.status !== 204) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `HTTP ${res.status}`);
  }
  return res.status === 204 ? null : res.json();
}

/* ---------- Companies ---------- */
async function loadCompanies() {
  try {
    state.companies = await api("/companies");
  } catch (err) {
    setListMsg("Failed to reach API: " + err.message + ". Is the server running?", "error");
    return;
  }
  if (!state.companies.length) {
    companySelect.innerHTML = `<option value="">No companies yet</option>`;
    statsBox.innerHTML = "";
    renderTable([]);
    setListMsg("No companies yet. Click \u201c+ Company\u201d to create one, then Import your Excel/CSV.");
    return;
  }
  companySelect.innerHTML = state.companies
    .map((c) => `<option value="${c.id}">${c.name}</option>`)
    .join("");
  if (!state.companyId || !state.companies.some((c) => c.id === state.companyId)) {
    state.companyId = state.companies[0].id;
  }
  localStorage.setItem("selectedCompanyId", state.companyId);
  companySelect.value = state.companyId;
  await loadSKUs();
}

// Per-company logos (matched case-insensitively by company name)
const COMPANY_LOGOS = { shyam: "assets/shyam-logo.png" };

function renderLogo() {
  const logo = el("company-logo");
  const c = state.companies.find((x) => x.id === state.companyId);
  const src = c ? COMPANY_LOGOS[c.name.trim().toLowerCase()] : null;
  if (src) {
    logo.src = src;
    logo.classList.remove("hidden");
  } else {
    logo.classList.add("hidden");
    logo.removeAttribute("src");
  }
}

function renderStats() {
  renderLogo();
  const c = state.companies.find((x) => x.id === state.companyId);
  if (!c) { statsBox.innerHTML = ""; return; }
  statsBox.innerHTML = `
    <div class="stat"><span class="stat-num">${c.sku_count}</span><span class="stat-label">SKUs</span></div>
    <div class="stat"><span class="stat-num">${c.total_units}</span><span class="stat-label">Units in stock</span></div>
    <div class="stat"><span class="stat-num">${state.showProfit ? money(c.total_stock_value) : MASK}</span><span class="stat-label">Stock value (buying)</span></div>
    <div class="stat"><span class="stat-num">${money(c.total_stock_value_selling)}</span><span class="stat-label">Stock value (selling)</span></div>
    <div class="stat profit"><span class="stat-num">${state.showProfit ? money(c.total_realized_profit) : MASK}</span><span class="stat-label">Realized profit (dispatched)</span></div>
    <div class="stat ${c.out_of_stock_count ? "warn" : ""}"><span class="stat-num">${c.out_of_stock_count}</span><span class="stat-label">Out of stock</span></div>`;
}

/* ---------- SKUs ---------- */
async function loadSKUs() {
  if (!state.companyId) return;
  const search = el("search").value.trim();
  const q = new URLSearchParams({ company_id: state.companyId });
  if (search) q.set("search", search);
  try {
    state.skus = await api(`/skus?${q.toString()}`);
    renderTable(state.skus);
    renderStats();
    setListMsg("");
  } catch (err) {
    setListMsg("Failed to load SKUs: " + err.message, "error");
  }
}

// Stable light tint per category (same name always maps to the same colour)
function categoryColor(cat) {
  const c = (cat || "").trim().toLowerCase();
  if (!c) return "";
  let h = 0;
  for (let i = 0; i < c.length; i++) h = (h * 31 + c.charCodeAt(i)) % 360;
  return `hsl(${h}, 55%, 92%)`;
}

function renderLegend(skus) {
  const box = el("category-legend");
  if (!box) return;
  const cats = [...new Set(skus.map((s) => (s.category || "").trim()).filter(Boolean))]
    .sort((a, b) => a.localeCompare(b));
  if (!cats.length) { box.innerHTML = ""; return; }
  box.innerHTML =
    `<span class="legend-label">Categories:</span>` +
    cats.map((c) =>
      `<span class="legend-item"><span class="legend-swatch" style="background:${categoryColor(c)}"></span>${c}</span>`
    ).join("");
}

function renderTable(skus) {
  renderLegend(skus);
  if (!skus.length) {
    tableBody.innerHTML = `<tr><td colspan="16" class="empty">No SKUs. Add one or import your Excel/CSV.</td></tr>`;
    return;
  }
  const outOfStock = (s) => s.quantity_on_hand <= 0;
  const costCell = (value) => (state.showProfit ? money(value) : `<span class="masked">${MASK}</span>`);
  const realizedProfitCell = (s) => {
    if (!state.showProfit) return `<span class="masked">${MASK}</span>`;
    if (!s.dispatched_qty) return '<span class="muted-cell">\u2014</span>';
    const cls = s.realized_profit < 0 ? "neg" : "pos";
    return `<span class="${cls}"><strong>${money(s.realized_profit)}</strong></span>`;
  };
  const unitProfitCell = (s) => {
    if (!state.showProfit) return `<span class="masked">${MASK}</span>`;
    if (s.selling_price <= 0) return '<span class="muted-cell">\u2014</span>';
    const cls = s.unit_profit < 0 ? "neg" : "pos";
    return `<span class="${cls}">${money(s.unit_profit)}</span>`;
  };
  tableBody.innerHTML = skus.map((s, i) => {
    const bg = categoryColor(s.category);
    const rowStyle = bg ? ` style="background:${bg}"` : "";
    const stickyStyle = bg ? ` style="background:${bg}"` : "";
    return `
    <tr class="${outOfStock(s) ? "row-oos" : ""}"${rowStyle}>
      <td class="num">${i + 1}</td>
      <td>${s.name}</td>
      <td>${s.variant ?? ""}</td>
      <td>${s.category ?? ""}</td>
      <td class="num">${money(s.mrp)}</td>
      <td class="num">${costCell(s.buying_price)}</td>
      <td class="num">${money(s.selling_price)}</td>
      <td class="num profit-col">${unitProfitCell(s)}</td>
      <td class="num">${s.opening_qty}</td>
      <td class="num">${s.dispatched_qty}</td>
      <td class="num"><strong>${s.quantity_on_hand}</strong></td>
      <td class="num">${costCell(s.total_price)}</td>
      <td class="num">${money(s.total_selling_price)}</td>
      <td class="num profit-col">${realizedProfitCell(s)}</td>
      <td>${outOfStock(s)
        ? '<span class="badge reorder">Out Of Stock</span>'
        : '<span class="badge ok">In Stock</span>'}</td>
      <td class="row-actions"${stickyStyle}>
        <button class="link out" data-out="${s.id}">Stock Out</button>
        <button class="link in" data-in="${s.id}">Stock In</button>
        <button class="link" data-edit="${s.id}">Edit</button>
        <button class="link danger" data-delete="${s.id}">Del</button>
      </td>
    </tr>`;
  }).join("");
}

/* ---------- Modals ---------- */
function openModal(id) { el(id).classList.remove("hidden"); }
function closeModals() { document.querySelectorAll(".modal").forEach((m) => m.classList.add("hidden")); }

function openSkuModal(sku = null) {
  el("sku-form").reset();
  el("sku-id").value = sku ? sku.id : "";
  el("modal-title").textContent = sku ? "Edit SKU" : "Add SKU";
  el("sku_code").disabled = Boolean(sku);
  el("quantity_on_hand").disabled = Boolean(sku); // qty changes only via stock in/out after creation
  if (sku) {
    el("sku_code").value = sku.sku_code;
    el("name").value = sku.name;
    el("variant").value = sku.variant ?? "";
    el("category").value = sku.category ?? "";
    el("mrp").value = sku.mrp;
    el("buying_price").value = sku.buying_price;
    el("selling_price").value = sku.selling_price;
    el("quantity_on_hand").value = sku.quantity_on_hand;
    el("reorder_level").value = sku.reorder_level;
    el("buying_pct").value = sku.mrp > 0 ? round2((sku.mrp - sku.buying_price) / sku.mrp * 100) : "";
    el("selling_pct").value = sku.mrp > 0 ? round2((sku.mrp - sku.selling_price) / sku.mrp * 100) : "";
  }
  el("form-msg").textContent = "";
  openModal("sku-modal");
}

/* ---------- Price <-> percentage-of-MRP sync ---------- */
function round2(n) {
  return Math.round((Number(n) + Number.EPSILON) * 100) / 100;
}
// % is a DISCOUNT off MRP: price = MRP - (pct% of MRP)
function priceFromPct(pctId, priceId) {
  const mrp = Number(el("mrp").value) || 0;
  const pct = Number(el(pctId).value);
  if (mrp > 0 && el(pctId).value !== "") el(priceId).value = round2(mrp * (1 - pct / 100));
}
// price changed -> derive the discount % from MRP
function pctFromPrice(priceId, pctId) {
  const mrp = Number(el("mrp").value) || 0;
  const price = Number(el(priceId).value);
  el(pctId).value = mrp > 0 && el(priceId).value !== "" ? round2((mrp - price) / mrp * 100) : "";
}
// MRP changed -> keep the % as the source of truth and recompute prices
function onMrpChange() {
  if (el("buying_pct").value !== "") priceFromPct("buying_pct", "buying_price");
  else pctFromPrice("buying_price", "buying_pct");
  if (el("selling_pct").value !== "") priceFromPct("selling_pct", "selling_price");
  else pctFromPrice("selling_price", "selling_pct");
}
el("buying_pct").addEventListener("input", () => priceFromPct("buying_pct", "buying_price"));
el("selling_pct").addEventListener("input", () => priceFromPct("selling_pct", "selling_price"));
el("buying_price").addEventListener("input", () => pctFromPrice("buying_price", "buying_pct"));
el("selling_price").addEventListener("input", () => pctFromPrice("selling_price", "selling_pct"));
el("mrp").addEventListener("input", onMrpChange);

el("sku-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = el("sku-id").value;
  const isUpdate = Boolean(id);
  const body = {
    name: el("name").value.trim(),
    variant: el("variant").value.trim() || null,
    category: el("category").value.trim() || null,
    mrp: Number(el("mrp").value),
    buying_price: Number(el("buying_price").value),
    selling_price: Number(el("selling_price").value),
    reorder_level: Number(el("reorder_level").value),
  };
  if (!isUpdate) {
    body.sku_code = el("sku_code").value.trim() || null;
    body.quantity_on_hand = Number(el("quantity_on_hand").value);
  }
  try {
    const path = isUpdate ? `/skus/${id}` : `/skus?company_id=${state.companyId}`;
    await api(path, {
      method: isUpdate ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    closeModals();
    await refreshAll();
  } catch (err) {
    el("form-msg").textContent = err.message;
    el("form-msg").className = "msg error";
  }
});

async function loadLotSuggestions() {
  if (!state.companyId) return;
  try {
    const lots = await api(`/companies/${state.companyId}/lots`);
    const names = [...new Set(lots.map((l) => l.lot_no))];
    el("lot-suggestions").innerHTML = names.map((n) => `<option value="${n}"></option>`).join("");
  } catch (_) { /* suggestions are optional */ }
}

function openStockModal(sku, type) {
  el("stock-form").reset();
  el("stock-sku-id").value = sku.id;
  el("stock-type").value = type;
  el("stock-title").textContent = type === "out" ? "Stock Out" : "Stock In";
  el("stock-submit").textContent = type === "out" ? "Confirm Stock Out" : "Confirm Stock In";
  el("stock-submit").className = type === "out" ? "danger-btn" : "";
  // Lot No only applies to stock-in (fresh stock arriving in a batch)
  const isIn = type !== "out";
  el("stock-lot-row").style.display = isIn ? "" : "none";
  el("stock-lot").required = isIn;
  el("stock-reason-row").style.display = isIn ? "none" : "";
  if (!isIn) el("stock-reason").value = "sale";
  if (isIn) loadLotSuggestions();
  el("stock-sku-label").textContent = `${sku.name}${sku.variant ? " - " + sku.variant : ""} (${sku.sku_code}) \u2014 on hand: ${sku.quantity_on_hand}`;
  el("stock-msg").textContent = "";
  openModal("stock-modal");
}

el("stock-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = el("stock-sku-id").value;
  const type = el("stock-type").value;
  const body = {
    quantity: Number(el("stock-qty").value),
    reference: el("stock-ref").value.trim() || null,
    note: el("stock-note").value.trim() || null,
  };
  if (type !== "out") {
    body.lot_no = el("stock-lot").value.trim() || null;
    body.received_date = el("stock-date").value || null;
  } else {
    body.reason = el("stock-reason").value || "sale";
  }
  try {
    await api(`/skus/${id}/stock-${type}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    closeModals();
    await refreshAll();
  } catch (err) {
    el("stock-msg").textContent = err.message;
    el("stock-msg").className = "msg error";
  }
});

/* ---------- Table actions ---------- */
tableBody.addEventListener("click", async (e) => {
  const t = e.target;
  const findSku = (id) => state.skus.find((s) => String(s.id) === String(id));
  if (t.dataset.out) return openStockModal(findSku(t.dataset.out), "out");
  if (t.dataset.in) return openStockModal(findSku(t.dataset.in), "in");
  if (t.dataset.edit) return openSkuModal(findSku(t.dataset.edit));
  if (t.dataset.delete) {
    if (!confirm("Delete this SKU and its stock history?")) return;
    try {
      await api(`/skus/${t.dataset.delete}`, { method: "DELETE" });
      await refreshAll();
    } catch (err) {
      alert("Delete failed: " + err.message);
    }
  }
});

/* ---------- Import / Export ---------- */
el("import-btn").addEventListener("click", () => {
  if (!state.companyId) return setListMsg("Create or select a company first.", "error");
  el("import-file").click();
});
el("import-file").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append("file", file);
  setListMsg("Importing " + file.name + "...");
  try {
    const r = await api(`/companies/${state.companyId}/import`, { method: "POST", body: fd });
    let msg = `Import done: ${r.created} created, ${r.updated} updated (of ${r.total_rows} rows).`;
    if (r.errors && r.errors.length) msg += ` ${r.errors.length} error(s): ${r.errors.slice(0, 3).join("; ")}`;
    setListMsg(msg, r.errors && r.errors.length ? "error" : "success");
    await refreshAll();
  } catch (err) {
    setListMsg("Import failed: " + err.message, "error");
  } finally {
    e.target.value = "";
  }
});
el("export-btn").addEventListener("click", () => {
  if (!state.companyId) return setListMsg("Create or select a company first.", "error");
  window.open(`${API_BASE}/companies/${state.companyId}/export`, "_blank");
});
el("stock-sheet-btn").addEventListener("click", () => {
  if (!state.companyId) return setListMsg("Create or select a company first.", "error");
  window.open(`stock-sheet.html?company_id=${state.companyId}`, "_blank");
});
el("clear-history-btn").addEventListener("click", async () => {
  if (!state.companyId) return setListMsg("Create or select a company first.", "error");
  const company = state.companies.find((c) => c.id === state.companyId);
  const name = company ? company.name : "this company";
  const answer = prompt(
    `This will clear the STOCK MOVEMENT HISTORY (stock-in / stock-out log) for all products in "${name}".\n` +
    `Your products, prices and current On-Hand quantities are KEPT.\n` +
    `This cannot be undone.\n\nType DELETE to confirm:`
  );
  if (answer === null) return; // cancelled
  if (answer.trim().toUpperCase() !== "DELETE") {
    return setListMsg("Cancelled - confirmation text did not match.", "error");
  }
  try {
    const res = await api(`/companies/${state.companyId}/stock-history`, { method: "DELETE" });
    setListMsg(`Cleared ${res.cleared} stock-history record(s). Products kept.`, "success");
    await loadSKUs();
  } catch (err) {
    setListMsg("Clear failed: " + err.message, "error");
  }
});

/* ---------- Company controls ---------- */
companySelect.addEventListener("change", async () => {
  state.companyId = Number(companySelect.value);
  localStorage.setItem("selectedCompanyId", state.companyId);
  await loadSKUs();
});
el("new-company-btn").addEventListener("click", async () => {
  const name = prompt("New company name:");
  if (!name || !name.trim()) return;
  try {
    const c = await api("/companies", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: name.trim() }),
    });
    state.companyId = c.id;
    await loadCompanies();
  } catch (err) {
    alert("Could not create company: " + err.message);
  }
});

el("add-btn").addEventListener("click", () => {
  if (!state.companyId) return setListMsg("Create or select a company first.", "error");
  openSkuModal();
});
el("toggle-profit").addEventListener("click", () => {
  state.showProfit = !state.showProfit;
  el("toggle-profit").textContent = state.showProfit ? "Hide Financials" : "Show Financials";
  el("toggle-profit").classList.toggle("active", state.showProfit);
  renderStats();
  renderTable(state.skus);
});
el("search").addEventListener("input", debounce(loadSKUs, 250));
document.querySelectorAll("[data-close-modal]").forEach((b) => b.addEventListener("click", closeModals));
document.querySelectorAll(".modal").forEach((m) =>
  m.addEventListener("click", (e) => { if (e.target === m) closeModals(); })
);

async function refreshAll() {
  state.companies = await api("/companies");
  companySelect.value = state.companyId;
  await loadSKUs();
}
function debounce(fn, ms) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

loadCompanies();
