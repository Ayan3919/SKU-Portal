# Stock SKU Portal

A lightweight portal for managing stock / inventory SKUs, built with **FastAPI** (Python) and a simple static frontend.

## Features

- REST API for SKU management (create, read, update, delete)
- Stock level tracking with reorder-level flagging
- SQLite storage by default (zero-config); swappable to Postgres/Oracle later
- Simple HTML/CSS/JS frontend that talks to the API
- Interactive API docs out of the box (Swagger UI)

## Project structure

```
stock_sku_portal/
├── backend/
│   ├── app/
│   │   ├── main.py            # FastAPI app entrypoint
│   │   ├── core/config.py     # Settings / env config
│   │   ├── api/routes/        # API endpoints (skus, health)
│   │   ├── models/            # SQLAlchemy ORM models
│   │   ├── schemas/           # Pydantic request/response schemas
│   │   ├── services/          # Business logic
│   │   └── db/database.py     # DB engine & session
│   ├── requirements.txt
│   └── .env.example
├── frontend/                  # Static UI (HTML/CSS/JS)
├── data/                      # SQLite db file lives here (gitignored)
├── tests/                     # Pytest tests
└── README.md
```

## Getting started

### 1. Create a virtual environment & install deps

```bash
cd backend
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
# source .venv/bin/activate

pip install -r requirements.txt
```

### 2. Configure environment (optional)

```bash
copy .env.example .env      # Windows
# cp .env.example .env      # macOS/Linux
```

### 3. Run the API

```bash
uvicorn app.main:app --reload
```

- API base: http://127.0.0.1:8000
- Swagger docs: http://127.0.0.1:8000/docs
- Health check: http://127.0.0.1:8000/api/health

### 4. Open the frontend

Open `frontend/index.html` in your browser (or serve it with any static server). It is configured to call the API at `http://127.0.0.1:8000`.

## Running tests

```bash
cd backend
pytest
```

## Next steps

- Swap SQLite for Postgres/Oracle by changing `DATABASE_URL` in `.env`
- Add authentication (API keys / JWT)
- Add stock movement history and reporting
