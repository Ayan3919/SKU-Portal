import hashlib
import secrets

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.user import AuthSession, User

_ITERATIONS = 100_000


def hash_password(password: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), _ITERATIONS)
    return f"{salt}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt, _ = stored.split("$", 1)
    except ValueError:
        return False
    return secrets.compare_digest(hash_password(password, salt), stored)


def get_user_by_username(db: Session, username: str) -> User | None:
    stmt = select(User).where(func.lower(User.username) == username.strip().lower())
    return db.execute(stmt).scalar_one_or_none()


def authenticate(db: Session, username: str, password: str) -> User | None:
    user = get_user_by_username(db, username)
    if not user or not verify_password(password, user.password_hash):
        return None
    return user


def create_session(db: Session, user: User) -> str:
    token = secrets.token_urlsafe(32)
    db.add(AuthSession(token=token, user_id=user.id))
    db.commit()
    return token


def get_user_by_token(db: Session, token: str | None) -> User | None:
    if not token:
        return None
    session = db.execute(select(AuthSession).where(AuthSession.token == token)).scalar_one_or_none()
    return db.get(User, session.user_id) if session else None


def delete_session(db: Session, token: str | None) -> None:
    if not token:
        return
    session = db.execute(select(AuthSession).where(AuthSession.token == token)).scalar_one_or_none()
    if session:
        db.delete(session)
        db.commit()


def seed_default_users(db: Session) -> None:
    """Create default accounts on first run. Change these passwords afterwards."""
    if db.execute(select(User.id)).first():
        return
    db.add(User(username="admin", display_name="Owner", role="owner", password_hash=hash_password("admin@123")))
    db.add(User(username="staff", display_name="Staff", role="staff", password_hash=hash_password("staff@123")))
    db.commit()
