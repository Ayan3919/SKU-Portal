@echo off
title Stock SKU Portal
cd /d "%~dp0backend"

echo ============================================
echo   Starting Stock SKU Portal...
echo ============================================
echo.

REM Start the API server in its own window (close that window to stop the portal)
start "Stock SKU Portal - Server (keep open)" .venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000

REM Give the server a few seconds to come up
timeout /t 4 /nobreak >nul

REM Open the portal in the default browser
start "" "%~dp0frontend\index.html"

echo Portal launched.
echo   - API:  http://127.0.0.1:8000
echo   - Docs: http://127.0.0.1:8000/docs
echo.
echo A separate "Server" window has opened. Keep it open while using the portal.
echo Close that window to stop the portal.
echo.
echo You can close THIS window now.
timeout /t 6 /nobreak >nul
