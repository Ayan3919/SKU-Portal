@echo off
title Stock SKU Portal - Offline Setup
cd /d "%~dp0"

echo ============================================
echo   Stock SKU Portal - OFFLINE Setup
echo   installs from the bundled wheelhouse
echo ============================================
echo.

REM Check Python is installed and on PATH
python --version >nul 2>&1
if errorlevel 1 goto no_python

REM Check the wheelhouse folder is present
if not exist "wheelhouse" goto no_wheelhouse

echo Python found:
python --version
echo.

cd backend

REM Create the virtual environment if it does not already exist
if not exist ".venv\Scripts\python.exe" goto make_venv
echo Virtual environment already exists - reusing it.
goto install

:make_venv
echo Creating virtual environment...
python -m venv .venv

:install
echo.
echo Installing dependencies from local wheelhouse - no internet required...
".venv\Scripts\python.exe" -m pip install --no-index --find-links "..\wheelhouse" -r requirements.txt
if errorlevel 1 goto install_failed

echo.
echo ============================================
echo   Offline setup complete!
echo ============================================
echo.
echo Start the portal by double-clicking "Start Portal.bat".
echo.
pause
exit /b 0

:no_python
echo [ERROR] Python was not found.
echo Install Python 3.14 64-bit - the same version this bundle was built for.
echo During install, tick "Add python.exe to PATH", then run this file again.
echo.
pause
exit /b 1

:no_wheelhouse
echo [ERROR] The "wheelhouse" folder is missing next to this script.
echo Make sure you extracted the whole zip, including the "wheelhouse" folder.
echo.
pause
exit /b 1

:install_failed
echo.
echo [ERROR] Dependency installation failed.
echo Most common cause: the installed Python version is not 3.14 64-bit.
echo Run this command to check versions:  py --list
echo.
pause
exit /b 1
