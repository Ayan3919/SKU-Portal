"""Database backup & restore for the SQLite data file.

Backups are timestamped copies of the whole database stored in data/backups/.
Creating a backup uses SQLite's online backup API so it is safe even while the
server is running. Restoring first takes an automatic safety snapshot of the
current data, then swaps the chosen backup in.
"""

import re
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

from app.core.config import PROJECT_ROOT, settings

_PREFIX = "sqlite:///"
_BACKUP_PREFIX = "stock_sku_backup_"
_SAFETY_PREFIX = "pre_restore_"
_STAMP_RE = re.compile(r"(\d{8}_\d{6})")


def _db_path() -> Path:
    url = settings.resolved_database_url
    if not url.startswith(_PREFIX):
        raise RuntimeError("Backups are only supported for SQLite databases.")
    return Path(url[len(_PREFIX):])


def _backups_dir() -> Path:
    d = PROJECT_ROOT / "data" / "backups"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _safe_name(name: str) -> str:
    """Reject path traversal and only allow our own .db backup files."""
    if not name or "/" in name or "\\" in name or ".." in name:
        raise ValueError("Invalid backup name")
    if not name.endswith(".db"):
        raise ValueError("Invalid backup name")
    return name


def _stamp_to_iso(name: str) -> str | None:
    m = _STAMP_RE.search(name)
    if not m:
        return None
    try:
        return datetime.strptime(m.group(1), "%Y%m%d_%H%M%S").isoformat()
    except ValueError:
        return None


def _sqlite_copy(src: Path, dst: Path) -> None:
    """Copy a SQLite DB safely using the online backup API."""
    src_conn = sqlite3.connect(str(src))
    dst_conn = sqlite3.connect(str(dst))
    try:
        with dst_conn:
            src_conn.backup(dst_conn)
    finally:
        src_conn.close()
        dst_conn.close()


def create_backup(label: str | None = None) -> dict:
    """Create a timestamped backup of the current database."""
    src = _db_path()
    if not src.exists():
        raise RuntimeError("Database file not found; nothing to back up yet.")
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    suffix = ""
    if label:
        clean = re.sub(r"[^A-Za-z0-9_-]+", "-", label.strip())[:40].strip("-")
        if clean:
            suffix = f"_{clean}"
    dest = _backups_dir() / f"{_BACKUP_PREFIX}{stamp}{suffix}.db"
    _sqlite_copy(src, dest)
    return _describe(dest)


def _describe(path: Path) -> dict:
    stat = path.stat()
    return {
        "name": path.name,
        "size_bytes": stat.st_size,
        "size_kb": round(stat.st_size / 1024, 1),
        "created_at": _stamp_to_iso(path.name) or datetime.fromtimestamp(stat.st_mtime).isoformat(),
        "is_safety": path.name.startswith(_SAFETY_PREFIX),
    }


def list_backups() -> list[dict]:
    """Newest first."""
    items = [_describe(p) for p in _backups_dir().glob("*.db")]
    items.sort(key=lambda x: x["created_at"], reverse=True)
    return items


def backup_file_path(name: str) -> Path:
    name = _safe_name(name)
    path = _backups_dir() / name
    if not path.exists():
        raise FileNotFoundError(name)
    return path


def delete_backup(name: str) -> None:
    backup_file_path(name).unlink()


def _restore_from(source: Path) -> dict:
    """Swap `source` in as the live database, after snapshotting current data."""
    from app.db.database import engine

    live = _db_path()
    # 1) safety snapshot of current data (best-effort)
    safety_name = None
    if live.exists():
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safety = _backups_dir() / f"{_SAFETY_PREFIX}{stamp}.db"
        _sqlite_copy(live, safety)
        safety_name = safety.name

    # 2) release pooled connections so the file is not locked (Windows)
    engine.dispose()

    # 3) replace the live DB, clearing any WAL side files
    shutil.copy2(source, live)
    for ext in ("-wal", "-shm"):
        side = Path(str(live) + ext)
        if side.exists():
            side.unlink()

    return {"restored": True, "safety_backup": safety_name}


def restore_backup(name: str) -> dict:
    return _restore_from(backup_file_path(name))


def restore_from_bytes(content: bytes) -> dict:
    """Restore from an uploaded .db file. Validates it is a real SQLite file."""
    if content[:16] != b"SQLite format 3\x00":
        raise ValueError("Uploaded file is not a valid SQLite database.")
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    tmp = _backups_dir() / f"upload_{stamp}.db"
    tmp.write_bytes(content)
    try:
        # sanity check it opens and has our tables
        conn = sqlite3.connect(str(tmp))
        try:
            conn.execute("SELECT 1 FROM skus LIMIT 1")
        finally:
            conn.close()
    except sqlite3.Error:
        tmp.unlink(missing_ok=True)
        raise ValueError("Uploaded database does not look like a Stock SKU Portal backup.")
    result = _restore_from(tmp)
    tmp.unlink(missing_ok=True)
    return result


def live_db_path() -> Path:
    return _db_path()
