const AUTH_API = "http://127.0.0.1:8000/api";

// Already signed in? Skip straight to the app.
if (localStorage.getItem("authToken")) {
  location.replace("index.html");
}

const form = document.getElementById("login-form");
const msg = document.getElementById("login-msg");
const btn = document.getElementById("login-btn");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  msg.textContent = "";
  btn.disabled = true;
  btn.textContent = "Signing in…";
  try {
    const res = await fetch(`${AUTH_API}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: document.getElementById("username").value.trim(),
        password: document.getElementById("password").value,
      }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || `Sign in failed (HTTP ${res.status})`);
    }
    const data = await res.json();
    localStorage.setItem("authToken", data.token);
    localStorage.setItem("authRole", data.role);
    localStorage.setItem("authName", data.display_name || data.username);
    location.replace("index.html");
  } catch (err) {
    const isNetwork = err instanceof TypeError;
    msg.textContent = isNetwork ? "Cannot reach the server. Is the portal running?" : err.message;
    btn.disabled = false;
    btn.textContent = "Sign in";
  }
});
