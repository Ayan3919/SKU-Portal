from datetime import date, datetime

from sqlalchemy import Date, DateTime, Float, ForeignKey, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


class Outlet(Base):
    """A retail outlet / counter that receives SKUs from a company's inventory."""

    __tablename__ = "outlets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    company_id: Mapped[int] = mapped_column(
        ForeignKey("companies.id", ondelete="CASCADE"), index=True, nullable=False
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    phone: Mapped[str | None] = mapped_column(String(32), nullable=True)
    location: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    dispatches: Mapped[list["OutletDispatch"]] = relationship(
        back_populates="outlet", cascade="all, delete-orphan"
    )
    payments: Mapped[list["OutletPaymentRecord"]] = relationship(
        back_populates="outlet", cascade="all, delete-orphan"
    )


class OutletDispatch(Base):
    """A line recording SKUs taken by an outlet, with amount owed and paid."""

    __tablename__ = "outlet_dispatches"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    outlet_id: Mapped[int] = mapped_column(
        ForeignKey("outlets.id", ondelete="CASCADE"), index=True, nullable=False
    )
    sku_id: Mapped[int | None] = mapped_column(
        ForeignKey("skus.id", ondelete="SET NULL"), index=True, nullable=True
    )
    # Snapshot of the item at dispatch time so the ledger stays readable
    item_name: Mapped[str] = mapped_column(String(255), nullable=False)
    variant: Mapped[str | None] = mapped_column(String(64), nullable=True)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    unit_price: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    # Snapshot of the item's buying price at dispatch time, for realized-profit tracking
    buying_price: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    total_amount: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    amount_paid: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    note: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    outlet: Mapped["Outlet"] = relationship(back_populates="dispatches")

    @property
    def pending_amount(self) -> float:
        return round(self.total_amount - self.amount_paid, 2)

    @property
    def profit(self) -> float:
        """Realized profit on this dispatch = (sale price - buying price) x qty."""
        return round((self.unit_price - self.buying_price) * self.quantity, 2)


class OutletPaymentRecord(Base):
    """A dated payment received from an outlet against its pending balance."""

    __tablename__ = "outlet_payments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    outlet_id: Mapped[int] = mapped_column(
        ForeignKey("outlets.id", ondelete="CASCADE"), index=True, nullable=False
    )
    amount: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    paid_on: Mapped[date | None] = mapped_column(Date, nullable=True)
    note: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    outlet: Mapped["Outlet"] = relationship(back_populates="payments")
