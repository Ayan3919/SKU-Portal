from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.sku import SKUOut
from app.schemas.stock_movement import StockChange, StockMovementOut
from app.services import stock_service, sku_service

router = APIRouter(prefix="/skus/{sku_id}", tags=["stock"])


def _get_sku_or_404(db: Session, sku_id: int):
    sku = sku_service.get_sku(db, sku_id)
    if not sku:
        raise HTTPException(status_code=404, detail="SKU not found")
    return sku


@router.post("/stock-in", response_model=SKUOut)
def stock_in(sku_id: int, payload: StockChange, db: Session = Depends(get_db)):
    sku = _get_sku_or_404(db, sku_id)
    stock_service.stock_in(
        db, sku, payload.quantity, payload.reference, payload.note,
        lot_no=payload.lot_no, received_date=payload.received_date,
    )
    return sku_service.get_sku(db, sku_id)


@router.post("/stock-out", response_model=SKUOut)
def stock_out(sku_id: int, payload: StockChange, db: Session = Depends(get_db)):
    sku = _get_sku_or_404(db, sku_id)
    try:
        stock_service.stock_out(
            db, sku, payload.quantity, payload.reference, payload.note, reason=payload.reason
        )
    except stock_service.InsufficientStockError as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    return sku


@router.get("/movements", response_model=list[StockMovementOut])
def list_movements(sku_id: int, limit: int = 100, db: Session = Depends(get_db)):
    _get_sku_or_404(db, sku_id)
    return stock_service.list_movements(db, sku_id, limit=limit)
