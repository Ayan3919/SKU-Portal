from collections import defaultdict
from datetime import date

from sqlalchemy import delete as sa_delete, select
from sqlalchemy.orm import Session

from app.models.outlet import Outlet, OutletDispatch, OutletPaymentRecord
from app.models.sku import SKU
from app.schemas.outlet import DispatchCreate, OrderCreate, OutletCreate, OutletUpdate
from app.services import stock_service


def list_outlets(db: Session, company_id: int) -> list[Outlet]:
    stmt = select(Outlet).where(Outlet.company_id == company_id).order_by(Outlet.name)
    return list(db.execute(stmt).scalars().all())


def get_outlet(db: Session, outlet_id: int) -> Outlet | None:
    return db.get(Outlet, outlet_id)


def create_outlet(db: Session, company_id: int, payload: OutletCreate) -> Outlet:
    outlet = Outlet(company_id=company_id, **payload.model_dump())
    db.add(outlet)
    db.commit()
    db.refresh(outlet)
    return outlet


def update_outlet(db: Session, outlet: Outlet, payload: OutletUpdate) -> Outlet:
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(outlet, field, value)
    db.commit()
    db.refresh(outlet)
    return outlet


def delete_outlet(db: Session, outlet: Outlet) -> None:
    db.delete(outlet)
    db.commit()


def delete_all_outlets(db: Session, company_id: int) -> int:
    """Delete every outlet for a company (and all their dispatch/order lines).
    Returns how many outlets were removed. Inventory stock is NOT returned."""
    outlets = list(db.execute(select(Outlet).where(Outlet.company_id == company_id)).scalars().all())
    if not outlets:
        return 0
    for o in outlets:
        db.delete(o)  # cascades to dispatches
    db.commit()
    return len(outlets)


def clear_all_dispatches(db: Session, company_id: int) -> int:
    """Delete every dispatch/order and payment record for a company's outlets,
    KEEPING the outlets themselves. Inventory stock is NOT added back.
    Returns how many dispatch lines were removed."""
    outlet_ids = list(
        db.execute(select(Outlet.id).where(Outlet.company_id == company_id)).scalars().all()
    )
    if not outlet_ids:
        return 0
    db.execute(
        sa_delete(OutletPaymentRecord).where(OutletPaymentRecord.outlet_id.in_(outlet_ids))
    )
    result = db.execute(
        sa_delete(OutletDispatch).where(OutletDispatch.outlet_id.in_(outlet_ids))
    )
    db.commit()
    return int(result.rowcount or 0)


def _default_price(sku: SKU) -> float:
    """Price to charge an outlet when none is given: the selling price, or MRP if unset."""
    return sku.selling_price if sku.selling_price and sku.selling_price > 0 else sku.mrp


def create_dispatch(db: Session, outlet: Outlet, sku: SKU, payload: DispatchCreate) -> OutletDispatch:
    """Dispatch SKUs to an outlet: reduces inventory (stock-out) and records the ledger line."""
    unit_price = payload.unit_price if payload.unit_price is not None else _default_price(sku)
    total = round(unit_price * payload.quantity, 2)

    # Reduce inventory first (raises InsufficientStockError if not enough on hand)
    stock_service.stock_out(
        db, sku, payload.quantity, reference=f"Outlet: {outlet.name}", note=payload.note
    )

    dispatch = OutletDispatch(
        outlet_id=outlet.id,
        sku_id=sku.id,
        item_name=sku.name,
        variant=sku.variant,
        quantity=payload.quantity,
        unit_price=unit_price,
        buying_price=sku.buying_price,
        total_amount=total,
        amount_paid=min(payload.amount_paid, total),
        note=payload.note,
    )
    db.add(dispatch)
    db.commit()
    db.refresh(dispatch)
    return dispatch


class OrderError(Exception):
    """Raised when an order references an invalid or mismatched SKU."""


def create_order(db: Session, outlet: Outlet, payload: OrderCreate) -> list[OutletDispatch]:
    """Dispatch multiple products to an outlet in one order.

    All items are validated first (SKU exists, belongs to the outlet's company, and
    enough stock is on hand) so the order is all-or-nothing. Any optional payment is
    then spread across the created lines in order.
    """
    # Resolve and validate every SKU up front
    resolved = []  # (item, sku, unit_price)
    needed = defaultdict(int)
    for item in payload.items:
        sku = db.get(SKU, item.sku_id)
        if sku is None:
            raise OrderError(f"SKU {item.sku_id} not found")
        if sku.company_id != outlet.company_id:
            raise OrderError(f"'{sku.name}' belongs to a different company")
        unit_price = item.unit_price if item.unit_price is not None else _default_price(sku)
        resolved.append((item, sku, unit_price))
        needed[sku.id] += item.quantity

    # Check total requested per SKU against available stock before touching anything
    for sku_id, qty in needed.items():
        sku = db.get(SKU, sku_id)
        if qty > sku.quantity_on_hand:
            raise stock_service.InsufficientStockError(sku.quantity_on_hand, qty)

    created: list[OutletDispatch] = []
    for item, sku, unit_price in resolved:
        total = round(unit_price * item.quantity, 2)
        stock_service.stock_out(
            db, sku, item.quantity, reference=f"Outlet: {outlet.name}", note=payload.note
        )
        dispatch = OutletDispatch(
            outlet_id=outlet.id,
            sku_id=sku.id,
            item_name=sku.name,
            variant=sku.variant,
            quantity=item.quantity,
            unit_price=unit_price,
            buying_price=sku.buying_price,
            total_amount=total,
            amount_paid=0.0,
            note=payload.note,
        )
        db.add(dispatch)
        created.append(dispatch)
    db.commit()

    # Spread any upfront payment across the new lines, first line first
    remaining = round(payload.amount_paid, 2)
    if remaining > 0:
        for d in created:
            if remaining <= 0:
                break
            pay = min(d.total_amount, remaining)
            d.amount_paid = round(pay, 2)
            remaining = round(remaining - pay, 2)
        db.commit()

    for d in created:
        db.refresh(d)
    return created


def update_dispatch(
    db: Session,
    dispatch: OutletDispatch,
    quantity: int | None = None,
    unit_price: float | None = None,
    note: str | None = None,
) -> OutletDispatch:
    """Edit a dispatch. Changing the quantity adjusts the SKU inventory by the difference:
    increasing the order removes more stock, decreasing it returns stock."""
    if quantity is not None and quantity != dispatch.quantity:
        delta = quantity - dispatch.quantity
        sku = db.get(SKU, dispatch.sku_id) if dispatch.sku_id is not None else None
        if sku is not None:
            if delta > 0:
                stock_service.stock_out(
                    db, sku, delta,
                    reference=f"Outlet: {dispatch.outlet.name} (order edit)",
                    note="Order quantity increased",
                )
            else:
                stock_service.stock_in(
                    db, sku, -delta,
                    reference=f"Outlet: {dispatch.outlet.name} (order edit)",
                    note="Order quantity decreased",
                )
        dispatch.quantity = quantity

    if unit_price is not None:
        dispatch.unit_price = unit_price
    if note is not None:
        dispatch.note = note

    dispatch.total_amount = round(dispatch.unit_price * dispatch.quantity, 2)
    dispatch.amount_paid = min(dispatch.amount_paid, dispatch.total_amount)
    db.commit()
    db.refresh(dispatch)
    return dispatch


def get_dispatch(db: Session, dispatch_id: int) -> OutletDispatch | None:
    return db.get(OutletDispatch, dispatch_id)


def add_payment(
    db: Session, dispatch: OutletDispatch, amount: float, paid_on: date | None = None
) -> OutletDispatch:
    before = dispatch.amount_paid
    dispatch.amount_paid = round(min(dispatch.amount_paid + amount, dispatch.total_amount), 2)
    applied = round(dispatch.amount_paid - before, 2)
    if applied > 0:
        label = dispatch.item_name + (f" - {dispatch.variant}" if dispatch.variant else "")
        db.add(
            OutletPaymentRecord(
                outlet_id=dispatch.outlet_id,
                amount=applied,
                paid_on=paid_on or date.today(),
                note=f"For {label}",
            )
        )
    db.commit()
    db.refresh(dispatch)
    return dispatch


def record_outlet_payment(
    db: Session,
    outlet: Outlet,
    amount: float,
    paid_on: date | None = None,
    note: str | None = None,
) -> float:
    """Apply a payment to the outlet's pending balance, allocating across its
    dispatch lines oldest-first, and log a dated payment record. Returns any
    leftover (overpayment) amount that was not applied."""
    remaining = round(amount, 2)
    for d in sorted(outlet.dispatches, key=lambda x: x.created_at):
        if remaining <= 0:
            break
        pending = round(d.total_amount - d.amount_paid, 2)
        if pending <= 0:
            continue
        pay = min(pending, remaining)
        d.amount_paid = round(d.amount_paid + pay, 2)
        remaining = round(remaining - pay, 2)
    applied = round(amount - remaining, 2)
    if applied > 0:
        db.add(
            OutletPaymentRecord(
                outlet_id=outlet.id,
                amount=applied,
                paid_on=paid_on or date.today(),
                note=note,
            )
        )
    db.commit()
    return remaining


def delete_dispatch(db: Session, dispatch: OutletDispatch, return_stock: bool = True) -> None:
    """Delete a dispatch line; optionally return the quantity back to inventory."""
    if return_stock and dispatch.sku_id is not None:
        sku = db.get(SKU, dispatch.sku_id)
        if sku is not None:
            stock_service.stock_in(
                db, sku, dispatch.quantity,
                reference=f"Outlet return: {dispatch.outlet.name}",
                note="Dispatch reversed",
            )
    db.delete(dispatch)
    db.commit()


def build_report(db: Session, company_id: int) -> list[dict]:
    """Flat list of every dispatch line for a company (with outlet info), oldest first.
    The print view filters/groups these by date or outlet on the client."""
    stmt = (
        select(OutletDispatch, Outlet)
        .join(Outlet, OutletDispatch.outlet_id == Outlet.id)
        .where(Outlet.company_id == company_id)
        .order_by(OutletDispatch.created_at, OutletDispatch.id)
    )
    lines = []
    for dispatch, outlet in db.execute(stmt).all():
        lines.append(
            {
                "outlet_id": outlet.id,
                "outlet_name": outlet.name,
                "location": outlet.location,
                "phone": outlet.phone,
                "item_name": dispatch.item_name,
                "variant": dispatch.variant,
                "quantity": dispatch.quantity,
                "unit_price": dispatch.unit_price,
                "total_amount": dispatch.total_amount,
                "amount_paid": dispatch.amount_paid,
                "pending_amount": dispatch.pending_amount,
                "created_at": dispatch.created_at,
            }
        )
    return lines


def build_collections(db: Session, company_id: int) -> list[dict]:
    """Per-outlet outstanding balances with ageing, for the collections view.
    Only outlets that currently owe money are returned, highest pending first.
    `days_overdue` is measured from the oldest still-unpaid dispatch."""
    today = date.today()
    outlets = list(
        db.execute(select(Outlet).where(Outlet.company_id == company_id)).scalars().all()
    )
    rows: list[dict] = []
    for o in outlets:
        total_amount = round(sum(d.total_amount for d in o.dispatches), 2)
        total_paid = round(sum(d.amount_paid for d in o.dispatches), 2)
        pending = round(total_amount - total_paid, 2)
        if pending <= 0:
            continue
        # Oldest dispatch line that still has an unpaid portion
        unpaid_dates = [d.created_at for d in o.dispatches if d.pending_amount > 0]
        oldest = min(unpaid_dates) if unpaid_dates else None
        days_overdue = (today - oldest.date()).days if oldest else 0
        pay_dates = [p.paid_on or p.created_at.date() for p in o.payments]
        last_payment = max(pay_dates) if pay_dates else None
        rows.append(
            {
                "outlet_id": o.id,
                "name": o.name,
                "location": o.location,
                "phone": o.phone,
                "total_amount": total_amount,
                "total_paid": total_paid,
                "pending": pending,
                "oldest_unpaid_date": oldest.date() if oldest else None,
                "days_overdue": days_overdue,
                "last_payment_date": last_payment,
            }
        )
    rows.sort(key=lambda r: r["pending"], reverse=True)
    return rows


def summarize(outlet: Outlet) -> dict:
    dispatches = outlet.dispatches
    total_products = sum(d.quantity for d in dispatches)
    total_amount = round(sum(d.total_amount for d in dispatches), 2)
    total_paid = round(sum(d.amount_paid for d in dispatches), 2)
    total_pending = round(total_amount - total_paid, 2)
    total_profit = round(sum(d.profit for d in dispatches), 2)
    last_updated = max((d.updated_at for d in dispatches), default=None)
    return {
        "id": outlet.id,
        "company_id": outlet.company_id,
        "name": outlet.name,
        "phone": outlet.phone,
        "location": outlet.location,
        "created_at": outlet.created_at,
        "dispatch_count": len(dispatches),
        "total_products": total_products,
        "total_amount": total_amount,
        "total_paid": total_paid,
        "total_pending": total_pending,
        "total_profit": total_profit,
        "last_updated": last_updated,
    }
