from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class CompanyBase(BaseModel):
    name: str = Field(..., max_length=255, examples=["Shyam"])


class CompanyCreate(CompanyBase):
    pass


class CompanyOut(CompanyBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    created_at: datetime


class CompanySummary(CompanyOut):
    sku_count: int
    total_units: int
    total_stock_value: float
    total_stock_value_selling: float
    total_realized_profit: float
    out_of_stock_count: int
