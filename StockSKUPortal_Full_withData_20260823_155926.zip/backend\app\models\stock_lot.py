from datetime import date, datetime

from sqlalchemy import Date, DateTime, ForeignKey, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


class StockLot(Base):
    """A batch (lot) of stock received for a product.

    A Lot No can be shared across many products (one shipment covering several
    SKUs) - it is simply a string, so multiple rows can carry the same lot_no.
    `quantity_remaining` is drawn down FIFO (oldest lot first) as stock is sold
    or dispatched. Units sold from a lot = quantity_received - quantity_remaining.
    """

    __tablename__ = "stock_lots"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    company_id: Mapped[int] = mapped_column(
        ForeignKey("companies.id", ondelete="CASCADE"), index=True, nullable=False
    )
    sku_id: Mapped[int] = mapped_column(
        ForeignKey("skus.id", ondelete="CASCADE"), index=True, nullable=False
    )
    lot_no: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    quantity_received: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    quantity_remaining: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    received_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    note: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    sku: Mapped["SKU"] = relationship(back_populates="lots")  # noqa: F821

    @property
    def sold(self) -> int:
        return max(self.quantity_received - self.quantity_remaining, 0)
