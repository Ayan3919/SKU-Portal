const API_BASE = "http://127.0.0.1:8000/api";
const COMPANY_LOGOS = { shyam: "assets/shyam-logo.png" };

const params = new URLSearchParams(location.search);
const companyId = Number(params.get("company_id"));
const scope = params.get("scope") || "all"; // day | outlet | all
const dateParam = params.get("date") || "";
const outletId = params.get("outlet_id") ? Number(params.get("outlet_id")) : null;

function money(n) {
  return "\u20b9" + Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function localDateKey(s) {
  const d = new Date(s);
  if (isNaN(d)) return "";
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
function prettyDate(s) {
  const d = new Date(s);
  return isNaN(d) ? "" : d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}
function prettyDateTime(s) {
  const d = new Date(s);
  return isNaN(d) ? "" : d.toLocaleString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}
function prettyDateKey(key) {
  const d = new Date(key + "T00:00:00");
  return isNaN(d) ? key : d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}

async function load() {
  let report;
  try {
    const res = await fetch(`${API_BASE}/companies/${companyId}/dispatch-report`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    report = await res.json();
  } catch (err) {
    document.getElementById("sheet").innerHTML = `<p class="empty">Could not load report: ${err.message}. Is the server running?</p>`;
    return;
  }

  let lines = report.lines;
  let scopeText = "All orders";
  if (scope === "day" && dateParam) {
    lines = lines.filter((l) => localDateKey(l.created_at) === dateParam);
    scopeText = `Orders on ${prettyDateKey(dateParam)}`;
  } else if (scope === "outlet" && outletId) {
    lines = lines.filter((l) => l.outlet_id === outletId);
    const first = lines[0];
    scopeText = first
      ? `Outlet: ${first.outlet_name}${first.location ? " \u2014 " + first.location : ""}`
      : "Outlet statement";
  }

  render(report, lines, scopeText);
}

function render(report, lines, scopeText) {
  const logo = COMPANY_LOGOS[(report.company_name || "").trim().toLowerCase()];
  const logoHtml = logo ? `<img src="${logo}" alt="logo" />` : "";

  // Group by outlet
  const groups = new Map();
  for (const l of lines) {
    if (!groups.has(l.outlet_id)) groups.set(l.outlet_id, []);
    groups.get(l.outlet_id).push(l);
  }

  const gQty = lines.reduce((a, l) => a + l.quantity, 0);
  const gAmount = lines.reduce((a, l) => a + l.total_amount, 0);
  const gPaid = lines.reduce((a, l) => a + l.amount_paid, 0);
  const gPending = lines.reduce((a, l) => a + l.pending_amount, 0);

  const blocks = [...groups.entries()].map(([, rows]) => {
    const o = rows[0];
    const sub = [o.location, o.phone].filter(Boolean).join(" \u00b7 ");
    const sQty = rows.reduce((a, l) => a + l.quantity, 0);
    const sAmount = rows.reduce((a, l) => a + l.total_amount, 0);
    const sPaid = rows.reduce((a, l) => a + l.amount_paid, 0);
    const sPending = rows.reduce((a, l) => a + l.pending_amount, 0);
    const body = rows.map((l) => `
      <tr>
        <td>${prettyDate(l.created_at)}</td>
        <td class="item">${l.item_name}</td>
        <td>${l.variant ?? ""}</td>
        <td class="num">${l.quantity}</td>
        <td class="num">${money(l.unit_price)}</td>
        <td class="num">${money(l.total_amount)}</td>
        <td class="num">${money(l.amount_paid)}</td>
        <td class="num">${money(l.pending_amount)}</td>
      </tr>`).join("");
    return `
      <div class="outlet-block">
        <p class="outlet-head">${o.outlet_name}</p>
        <p class="outlet-sub">${sub || "&nbsp;"}</p>
        <table>
          <thead>
            <tr>
              <th>Date</th><th class="item">Item</th><th>Varient</th><th class="num">Qty</th>
              <th class="num">Unit Price</th><th class="num">Amount</th><th class="num">Paid</th><th class="num">Pending</th>
            </tr>
          </thead>
          <tbody>${body}</tbody>
          <tfoot>
            <tr>
              <td colspan="3">Subtotal (${rows.length} line${rows.length > 1 ? "s" : ""})</td>
              <td class="num">${sQty}</td><td></td>
              <td class="num">${money(sAmount)}</td><td class="num">${money(sPaid)}</td><td class="num">${money(sPending)}</td>
            </tr>
          </tfoot>
        </table>
      </div>`;
  }).join("");

  const inner = lines.length
    ? `
      <div class="totals">
        <div class="tot"><div class="n">${groups.size}</div><div class="l">Outlets</div></div>
        <div class="tot"><div class="n">${lines.length}</div><div class="l">Order lines</div></div>
        <div class="tot"><div class="n">${gQty}</div><div class="l">Total qty</div></div>
        <div class="tot"><div class="n">${money(gAmount)}</div><div class="l">Total amount</div></div>
        <div class="tot"><div class="n">${money(gPaid)}</div><div class="l">Payment received</div></div>
        <div class="tot pending"><div class="n">${money(gPending)}</div><div class="l">Pending</div></div>
      </div>
      ${blocks}
      <div class="rpt-foot">
        <div class="sign">Prepared by</div>
        <div class="sign">Received by</div>
      </div>`
    : `<p class="empty">No orders found for this selection.</p>`;

  document.getElementById("sheet").innerHTML = `
    <div class="rpt-header">
      <div class="rpt-brand">
        ${logoHtml}
        <div>
          <h1>${report.company_name}</h1>
          <div class="tag">Stock SKU Portal &middot; Dispatch &amp; Payment Report</div>
        </div>
      </div>
      <div class="rpt-meta">
        <div class="rpt-title">Dispatch Report</div>
        <div>Generated: ${prettyDateTime(report.generated_at)}</div>
      </div>
    </div>
    <p class="scope-line"><b>${scopeText}</b></p>
    ${inner}`;

  document.title = `${report.company_name} - ${scopeText}`;
}

load();
