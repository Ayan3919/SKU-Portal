from datetime import date

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.sku import SKU
from app.models.stock_movement import StockMovement
from app.services import lot_service


class InsufficientStockError(Exception):
    def __init__(self, available: int, requested: int):
        self.available = available
        self.requested = requested
        super().__init__(
            f"Insufficient stock: {available} on hand, {requested} requested"
        )


def _record(
    db: Session,
    sku: SKU,
    change: int,
    movement_type: str,
    reference: str | None,
    note: str | None,
) -> StockMovement:
    sku.quantity_on_hand += change
    movement = StockMovement(
        sku_id=sku.id,
        movement_type=movement_type,
        change=change,
        balance_after=sku.quantity_on_hand,
        reference=reference,
        note=note,
    )
    db.add(movement)
    db.commit()
    db.refresh(movement)
    db.refresh(sku)
    return movement


def stock_in(
    db: Session,
    sku: SKU,
    quantity: int,
    reference=None,
    note=None,
    lot_no: str | None = None,
    received_date: date | None = None,
) -> StockMovement:
    """Add stock. Fresh stock carries a Lot No and creates/tops-up that lot.
    When no lot_no is given (e.g. an outlet return), the units are put back into
    the most-recently consumed lots so lot totals stay consistent."""
    qty = abs(quantity)
    movement = _record(db, sku, qty, "in", reference, note)
    if lot_no and lot_no.strip():
        lot_service.add_to_lot(db, sku, lot_no.strip(), qty, received_date, note)
    else:
        lot_service.return_to_lots(db, sku, qty)
    return movement


def stock_out(
    db: Session,
    sku: SKU,
    quantity: int,
    reference=None,
    note=None,
    reason: str | None = None,
) -> StockMovement:
    """Remove stock. ``reason="correction"`` undoes a mistaken stock-in: it
    reduces the lot's received quantity so it is NOT counted as sold. Any other
    reason is a normal sale/dispatch drawn down FIFO (counts as sold)."""
    qty = abs(quantity)
    if qty > sku.quantity_on_hand:
        raise InsufficientStockError(sku.quantity_on_hand, qty)
    is_correction = (reason or "").strip().lower() == "correction"
    movement = _record(db, sku, -qty, "correction" if is_correction else "out", reference, note)
    if is_correction:
        lot_service.remove_from_lots(db, sku, qty)
    else:
        lot_service.consume_fifo(db, sku, qty)
    return movement


def list_movements(db: Session, sku_id: int, limit: int = 100) -> list[StockMovement]:
    stmt = (
        select(StockMovement)
        .where(StockMovement.sku_id == sku_id)
        .order_by(StockMovement.created_at.desc(), StockMovement.id.desc())
        .limit(limit)
    )
    return list(db.execute(stmt).scalars().all())
