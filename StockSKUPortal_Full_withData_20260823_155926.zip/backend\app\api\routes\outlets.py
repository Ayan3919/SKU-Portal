from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.outlet import (
    CollectionRow,
    DispatchCreate,
    DispatchOut,
    DispatchPayment,
    DispatchUpdate,
    DispatchReport,
    OrderCreate,
    OutletCreate,
    OutletDetail,
    OutletOut,
    OutletPayment,
    OutletPaymentResult,
    OutletSummary,
    OutletUpdate,
)
from app.services import company_service, outlet_service, sku_service, stock_service

router = APIRouter(tags=["outlets"])


def _get_outlet_or_404(db: Session, outlet_id: int):
    outlet = outlet_service.get_outlet(db, outlet_id)
    if not outlet:
        raise HTTPException(status_code=404, detail="Outlet not found")
    return outlet


@router.get("/companies/{company_id}/outlets", response_model=list[OutletSummary])
def list_outlets(company_id: int, db: Session = Depends(get_db)):
    if not company_service.get_company(db, company_id):
        raise HTTPException(status_code=404, detail="Company not found")
    return [outlet_service.summarize(o) for o in outlet_service.list_outlets(db, company_id)]


@router.delete("/companies/{company_id}/outlets")
def delete_all_outlets(company_id: int, db: Session = Depends(get_db)):
    """Delete ALL outlets (and their orders) for this company (irreversible)."""
    if not company_service.get_company(db, company_id):
        raise HTTPException(status_code=404, detail="Company not found")
    deleted = outlet_service.delete_all_outlets(db, company_id)
    return {"deleted": deleted}


@router.delete("/companies/{company_id}/dispatches")
def clear_all_dispatches(company_id: int, db: Session = Depends(get_db)):
    """Clear ALL dispatch/order & payment records for this company's outlets,
    keeping the outlets themselves. Irreversible."""
    if not company_service.get_company(db, company_id):
        raise HTTPException(status_code=404, detail="Company not found")
    cleared = outlet_service.clear_all_dispatches(db, company_id)
    return {"cleared": cleared}


@router.post("/companies/{company_id}/outlets", response_model=OutletOut, status_code=status.HTTP_201_CREATED)
def create_outlet(company_id: int, payload: OutletCreate, db: Session = Depends(get_db)):
    if not company_service.get_company(db, company_id):
        raise HTTPException(status_code=404, detail="Company not found")
    return outlet_service.create_outlet(db, company_id, payload)


@router.get("/companies/{company_id}/collections", response_model=list[CollectionRow])
def collections(company_id: int, db: Session = Depends(get_db)):
    if not company_service.get_company(db, company_id):
        raise HTTPException(status_code=404, detail="Company not found")
    return outlet_service.build_collections(db, company_id)


@router.get("/companies/{company_id}/dispatch-report", response_model=DispatchReport)
def dispatch_report(company_id: int, db: Session = Depends(get_db)):
    company = company_service.get_company(db, company_id)
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")
    from datetime import datetime, timezone

    return {
        "company_name": company.name,
        "generated_at": datetime.now(timezone.utc),
        "lines": outlet_service.build_report(db, company_id),
    }


@router.get("/outlets/{outlet_id}", response_model=OutletDetail)
def get_outlet(outlet_id: int, db: Session = Depends(get_db)):
    outlet = _get_outlet_or_404(db, outlet_id)
    summary = outlet_service.summarize(outlet)
    summary["dispatches"] = sorted(outlet.dispatches, key=lambda d: d.created_at, reverse=True)
    summary["payments"] = sorted(
        outlet.payments, key=lambda p: (p.paid_on or p.created_at.date(), p.id), reverse=True
    )
    company = company_service.get_company(db, outlet.company_id)
    summary["company_name"] = company.name if company else None
    return summary


@router.put("/outlets/{outlet_id}", response_model=OutletOut)
def update_outlet(outlet_id: int, payload: OutletUpdate, db: Session = Depends(get_db)):
    outlet = _get_outlet_or_404(db, outlet_id)
    return outlet_service.update_outlet(db, outlet, payload)


@router.delete("/outlets/{outlet_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_outlet(outlet_id: int, db: Session = Depends(get_db)):
    outlet_service.delete_outlet(db, _get_outlet_or_404(db, outlet_id))


@router.post("/outlets/{outlet_id}/payment", response_model=OutletPaymentResult)
def record_outlet_payment(outlet_id: int, payload: OutletPayment, db: Session = Depends(get_db)):
    outlet = _get_outlet_or_404(db, outlet_id)
    leftover = outlet_service.record_outlet_payment(
        db, outlet, payload.amount, paid_on=payload.paid_on, note=payload.note
    )
    summary = outlet_service.summarize(outlet)
    return {
        "allocated": round(payload.amount - leftover, 2),
        "leftover": leftover,
        "total_pending": summary["total_pending"],
        "total_paid": summary["total_paid"],
    }


@router.post("/outlets/{outlet_id}/dispatches", response_model=DispatchOut, status_code=status.HTTP_201_CREATED)
def create_dispatch(outlet_id: int, payload: DispatchCreate, db: Session = Depends(get_db)):
    outlet = _get_outlet_or_404(db, outlet_id)
    sku = sku_service.get_sku(db, payload.sku_id)
    if not sku:
        raise HTTPException(status_code=404, detail="SKU not found")
    if sku.company_id != outlet.company_id:
        raise HTTPException(status_code=400, detail="SKU belongs to a different company")
    try:
        return outlet_service.create_dispatch(db, outlet, sku, payload)
    except stock_service.InsufficientStockError as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@router.post("/outlets/{outlet_id}/orders", response_model=list[DispatchOut], status_code=status.HTTP_201_CREATED)
def create_order(outlet_id: int, payload: OrderCreate, db: Session = Depends(get_db)):
    outlet = _get_outlet_or_404(db, outlet_id)
    try:
        return outlet_service.create_order(db, outlet, payload)
    except outlet_service.OrderError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except stock_service.InsufficientStockError as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@router.put("/dispatches/{dispatch_id}", response_model=DispatchOut)
def update_dispatch(dispatch_id: int, payload: DispatchUpdate, db: Session = Depends(get_db)):
    dispatch = outlet_service.get_dispatch(db, dispatch_id)
    if not dispatch:
        raise HTTPException(status_code=404, detail="Dispatch not found")
    try:
        return outlet_service.update_dispatch(
            db, dispatch,
            quantity=payload.quantity, unit_price=payload.unit_price, note=payload.note,
        )
    except stock_service.InsufficientStockError as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@router.post("/dispatches/{dispatch_id}/payment", response_model=DispatchOut)
def record_payment(dispatch_id: int, payload: DispatchPayment, db: Session = Depends(get_db)):
    dispatch = outlet_service.get_dispatch(db, dispatch_id)
    if not dispatch:
        raise HTTPException(status_code=404, detail="Dispatch not found")
    return outlet_service.add_payment(db, dispatch, payload.amount)


@router.delete("/dispatches/{dispatch_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_dispatch(dispatch_id: int, return_stock: bool = True, db: Session = Depends(get_db)):
    dispatch = outlet_service.get_dispatch(db, dispatch_id)
    if not dispatch:
        raise HTTPException(status_code=404, detail="Dispatch not found")
    outlet_service.delete_dispatch(db, dispatch, return_stock=return_stock)
