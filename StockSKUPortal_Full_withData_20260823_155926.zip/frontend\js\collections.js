const API_BASE = "http://127.0.0.1:8000/api";

const el = (id) => document.getElementById(id);
const state = { companyId: null, companies: [], rows: [] };

const savedCompanyId = Number(localStorage.getItem("selectedCompanyId")) || null;
if (savedCompanyId) state.companyId = savedCompanyId;

const companySelect = el("company-select");
const tableBody = document.querySelector("#coll-table tbody");
const statsBox = el("stats");
const listMsg = el("list-msg");

function money(n) {
  return "\u20b9" + Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );
}
function fmtDate(s) {
  if (!s) return "\u2014";
  const d = new Date(s);
  return isNaN(d) ? esc(s) : d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}
function setListMsg(text, type = "") {
  listMsg.textContent = text;
  listMsg.className = "msg" + (type ? " " + type : "");
}
async function api(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, options);
  if (!res.ok && res.status !== 204) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `HTTP ${res.status}`);
  }
  return res.status === 204 ? null : res.json();
}
function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

const COMPANY_LOGOS = { shyam: "assets/shyam-logo.png" };
function renderLogo() {
  const logo = el("company-logo");
  const c = state.companies.find((x) => x.id === state.companyId);
  const src = c ? COMPANY_LOGOS[c.name.trim().toLowerCase()] : null;
  if (src) { logo.src = src; logo.classList.remove("hidden"); }
  else { logo.classList.add("hidden"); logo.removeAttribute("src"); }
}

async function loadCompanies() {
  try {
    state.companies = await api("/companies");
  } catch (err) {
    setListMsg("Failed to reach API: " + err.message + ". Is the server running?", "error");
    return;
  }
  if (!state.companies.length) {
    companySelect.innerHTML = `<option value="">No companies</option>`;
    setListMsg("No companies yet. Create one on the Inventory page first.");
    return;
  }
  companySelect.innerHTML = state.companies.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join("");
  if (!state.companyId || !state.companies.some((c) => c.id === state.companyId)) {
    state.companyId = state.companies[0].id;
  }
  localStorage.setItem("selectedCompanyId", state.companyId);
  companySelect.value = state.companyId;
  renderLogo();
  await loadCollections();
}

async function loadCollections() {
  if (!state.companyId) return;
  try {
    state.rows = await api(`/companies/${state.companyId}/collections`);
    renderStats();
    renderTable();
    setListMsg("");
  } catch (err) {
    setListMsg("Failed to load collections: " + err.message, "error");
  }
}

function bucketOf(days) {
  if (days <= 30) return "0";
  if (days <= 60) return "31";
  if (days <= 90) return "61";
  return "91";
}
function ageClass(days) {
  if (days > 90) return "age-bad";
  if (days > 60) return "age-warn";
  if (days > 30) return "age-mild";
  return "";
}

function renderStats() {
  const rows = state.rows;
  const totalPending = rows.reduce((a, r) => a + r.pending, 0);
  const buckets = { "0": 0, "31": 0, "61": 0, "91": 0 };
  rows.forEach((r) => { buckets[bucketOf(r.days_overdue)] += r.pending; });
  statsBox.innerHTML = `
    <div class="stat ${totalPending > 0 ? "warn" : ""}"><span class="stat-num">${money(totalPending)}</span><span class="stat-label">Total outstanding</span></div>
    <div class="stat"><span class="stat-num">${rows.length}</span><span class="stat-label">Outlets owing</span></div>
    <div class="stat"><span class="stat-num">${money(buckets["0"])}</span><span class="stat-label">0-30 days</span></div>
    <div class="stat"><span class="stat-num">${money(buckets["31"])}</span><span class="stat-label">31-60 days</span></div>
    <div class="stat"><span class="stat-num">${money(buckets["61"] + buckets["91"])}</span><span class="stat-label">60+ days</span></div>`;
}

function renderTable() {
  const term = el("search").value.trim().toLowerCase();
  const ageSel = el("age-filter").value;
  let rows = state.rows;
  if (term) {
    rows = rows.filter((r) => [r.name, r.location, r.phone].some((v) => (v || "").toLowerCase().includes(term)));
  }
  if (ageSel !== "all") {
    rows = rows.filter((r) => bucketOf(r.days_overdue) === ageSel);
  }
  if (!rows.length) {
    tableBody.innerHTML = `<tr><td colspan="10" class="empty">${state.rows.length ? "No outlets match the filter." : "Nothing pending \u2014 all outlets are fully paid."}</td></tr>`;
    return;
  }
  tableBody.innerHTML = rows.map((r) => `
    <tr class="${ageClass(r.days_overdue)}">
      <td><strong>${esc(r.name)}</strong></td>
      <td>${esc(r.location ?? "")}</td>
      <td>${esc(r.phone ?? "")}</td>
      <td class="num">${money(r.total_amount)}</td>
      <td class="num">${money(r.total_paid)}</td>
      <td class="num"><strong>${money(r.pending)}</strong></td>
      <td>${fmtDate(r.oldest_unpaid_date)}</td>
      <td class="num"><strong>${r.days_overdue}</strong></td>
      <td>${fmtDate(r.last_payment_date)}</td>
      <td class="row-actions">
        <button class="link in" data-pay="${r.outlet_id}" data-name="${esc(r.name)}" data-pending="${r.pending}">Record Payment</button>
        <button class="link" data-bill="${r.outlet_id}">Print Bill</button>
      </td>
    </tr>`).join("");
}

tableBody.addEventListener("click", (e) => {
  const t = e.target;
  if (t.dataset.bill) {
    window.open(`bill.html?outlet_id=${t.dataset.bill}`, "_blank");
    return;
  }
  if (t.dataset.pay) {
    el("payment-form").reset();
    el("payment-outlet-id").value = t.dataset.pay;
    el("payment-date").value = todayStr();
    el("payment-outlet-label").textContent = `${t.dataset.name} \u2014 pending: ${money(Number(t.dataset.pending))}`;
    el("payment-msg").textContent = "";
    el("payment-modal").classList.remove("hidden");
  }
});

el("payment-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const outletId = Number(el("payment-outlet-id").value);
  const amount = Number(el("payment-amount").value);
  if (!(amount > 0)) { setPaymentMsg("Enter an amount greater than 0.", "error"); return; }
  const body = {
    amount,
    paid_on: el("payment-date").value || null,
    note: el("payment-note").value.trim() || null,
  };
  try {
    const r = await api(`/outlets/${outletId}/payment`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });
    closeModals();
    if (r.leftover > 0) {
      alert(`Recorded ${money(r.allocated)}. This outlet is now fully paid; ${money(r.leftover)} was more than the pending balance and was not applied.`);
    }
    await loadCollections();
  } catch (err) { setPaymentMsg("Payment failed: " + err.message, "error"); }
});

function setPaymentMsg(text, type = "") {
  el("payment-msg").textContent = text;
  el("payment-msg").className = "msg" + (type ? " " + type : "");
}
function closeModals() { document.querySelectorAll(".modal").forEach((m) => m.classList.add("hidden")); }

companySelect.addEventListener("change", async () => {
  state.companyId = Number(companySelect.value);
  localStorage.setItem("selectedCompanyId", state.companyId);
  renderLogo();
  await loadCollections();
});
el("search").addEventListener("input", renderTable);
el("age-filter").addEventListener("change", renderTable);
document.querySelectorAll("[data-close-modal]").forEach((b) => b.addEventListener("click", closeModals));
document.querySelectorAll(".modal").forEach((m) =>
  m.addEventListener("click", (e) => { if (e.target === m) closeModals(); })
);

loadCompanies();
