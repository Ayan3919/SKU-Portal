from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.company import Company
from app.models.outlet import Outlet, OutletDispatch
from app.models.sku import SKU


def list_companies(db: Session) -> list[Company]:
    return list(db.execute(select(Company).order_by(Company.name)).scalars().all())


def get_company(db: Session, company_id: int) -> Company | None:
    return db.get(Company, company_id)


def get_company_by_name(db: Session, name: str) -> Company | None:
    stmt = select(Company).where(func.lower(Company.name) == name.strip().lower())
    return db.execute(stmt).scalar_one_or_none()


def create_company(db: Session, name: str) -> Company:
    company = Company(name=name.strip())
    db.add(company)
    db.commit()
    db.refresh(company)
    return company


def get_or_create_company(db: Session, name: str) -> Company:
    existing = get_company_by_name(db, name)
    if existing:
        return existing
    return create_company(db, name)


def delete_company(db: Session, company: Company) -> None:
    db.delete(company)
    db.commit()


def summarize(db: Session, company: Company) -> dict:
    rows = list(
        db.execute(select(SKU).where(SKU.company_id == company.id)).scalars().all()
    )
    total_units = sum(s.quantity_on_hand for s in rows)
    total_value = round(sum(s.quantity_on_hand * s.buying_price for s in rows), 2)
    total_value_selling = round(sum(s.quantity_on_hand * s.selling_price for s in rows), 2)
    out_of_stock_count = sum(1 for s in rows if s.quantity_on_hand <= 0)

    # Realized profit = actual profit booked as goods were dispatched to outlets
    realized = db.execute(
        select(
            func.coalesce(
                func.sum(
                    (OutletDispatch.unit_price - OutletDispatch.buying_price)
                    * OutletDispatch.quantity
                ),
                0.0,
            )
        )
        .select_from(OutletDispatch)
        .join(Outlet, OutletDispatch.outlet_id == Outlet.id)
        .where(Outlet.company_id == company.id)
    ).scalar_one()
    total_realized_profit = round(float(realized or 0.0), 2)

    return {
        "id": company.id,
        "name": company.name,
        "created_at": company.created_at,
        "sku_count": len(rows),
        "total_units": total_units,
        "total_stock_value": total_value,
        "total_stock_value_selling": total_value_selling,
        "total_realized_profit": total_realized_profit,
        "out_of_stock_count": out_of_stock_count,
    }
