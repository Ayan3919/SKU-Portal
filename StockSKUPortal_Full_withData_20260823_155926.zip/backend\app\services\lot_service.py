"""Lot / batch tracking.

Every unit of stock lives in a lot (a received batch identified by a Lot No).
Stock is drawn down FIFO - the oldest lot is emptied first. The sum of all lots'
`quantity_remaining` for a product mirrors its `quantity_on_hand`.
"""

from datetime import date

from sqlalchemy import delete as sa_delete, func, select, update
from sqlalchemy.orm import Session

from app.models.sku import SKU
from app.models.stock_lot import StockLot
from app.models.stock_movement import StockMovement

DEFAULT_LOT_NO = "OPENING"


def _lots_for_sku(db: Session, sku_id: int, oldest_first: bool = True) -> list[StockLot]:
    order = (StockLot.received_date, StockLot.id) if oldest_first else (
        StockLot.received_date.desc(),
        StockLot.id.desc(),
    )
    stmt = select(StockLot).where(StockLot.sku_id == sku_id).order_by(*order)
    return list(db.execute(stmt).scalars().all())


def add_to_lot(
    db: Session,
    sku: SKU,
    lot_no: str,
    quantity: int,
    received_date: date | None = None,
    note: str | None = None,
) -> StockLot:
    """Add received stock to a lot for this SKU. If a lot with the same lot_no
    already exists for the SKU, top it up; otherwise create a new one."""
    qty = abs(int(quantity))
    lot_no = (lot_no or DEFAULT_LOT_NO).strip() or DEFAULT_LOT_NO
    existing = db.execute(
        select(StockLot).where(StockLot.sku_id == sku.id, StockLot.lot_no == lot_no)
    ).scalar_one_or_none()
    if existing:
        existing.quantity_received += qty
        existing.quantity_remaining += qty
        if received_date:
            existing.received_date = received_date
        if note:
            existing.note = note
        db.commit()
        db.refresh(existing)
        return existing
    lot = StockLot(
        company_id=sku.company_id,
        sku_id=sku.id,
        lot_no=lot_no,
        quantity_received=qty,
        quantity_remaining=qty,
        received_date=received_date or date.today(),
        note=note,
    )
    db.add(lot)
    db.commit()
    db.refresh(lot)
    return lot


def consume_fifo(db: Session, sku: SKU, quantity: int) -> None:
    """Draw down `quantity` units from this SKU's lots, oldest lot first."""
    remaining = abs(int(quantity))
    if remaining <= 0:
        return
    for lot in _lots_for_sku(db, sku.id, oldest_first=True):
        if remaining <= 0:
            break
        if lot.quantity_remaining <= 0:
            continue
        take = min(lot.quantity_remaining, remaining)
        lot.quantity_remaining -= take
        remaining -= take
    db.commit()


def remove_from_lots(db: Session, sku: SKU, quantity: int) -> None:
    """Undo a mistaken receipt (a correction, NOT a sale).

    Reduces both ``quantity_received`` and ``quantity_remaining`` together,
    newest lot first, so a lot's ``sold`` (received - remaining) is unchanged
    and the correction never shows up as sold quantity. Only on-hand units can
    be un-received - units already sold cannot be corrected away. A lot that
    ends up fully empty (nothing received) is deleted.
    """
    remaining = abs(int(quantity))
    if remaining <= 0:
        return
    for lot in _lots_for_sku(db, sku.id, oldest_first=False):  # newest first
        if remaining <= 0:
            break
        take = min(lot.quantity_remaining, remaining)
        if take <= 0:
            continue
        lot.quantity_remaining -= take
        lot.quantity_received -= take
        remaining -= take
        if lot.quantity_received <= 0 and lot.quantity_remaining <= 0:
            db.delete(lot)
    db.commit()


def return_to_lots(db: Session, sku: SKU, quantity: int) -> None:
    """Put `quantity` units back (e.g. an outlet return or reduced order).
    Refills the most-recently consumed lots first so lot totals stay consistent."""
    remaining = abs(int(quantity))
    if remaining <= 0:
        return
    lots = _lots_for_sku(db, sku.id, oldest_first=False)  # newest first
    for lot in lots:
        if remaining <= 0:
            break
        room = lot.quantity_received - lot.quantity_remaining
        if room <= 0:
            continue
        put = min(room, remaining)
        lot.quantity_remaining += put
        remaining -= put
    if remaining > 0:
        # No room in existing lots - park the leftover on the newest lot, or open one.
        if lots:
            lots[0].quantity_received += remaining
            lots[0].quantity_remaining += remaining
        else:
            db.add(
                StockLot(
                    company_id=sku.company_id,
                    sku_id=sku.id,
                    lot_no=DEFAULT_LOT_NO,
                    quantity_received=remaining,
                    quantity_remaining=remaining,
                    received_date=date.today(),
                )
            )
    db.commit()


def list_company_lots(db: Session, company_id: int, search: str | None = None) -> list[dict]:
    """All lot rows for a company, enriched with product info. Oldest first."""
    stmt = (
        select(StockLot, SKU)
        .join(SKU, StockLot.sku_id == SKU.id)
        .where(StockLot.company_id == company_id)
    )
    if search:
        like = f"%{search.strip()}%"
        stmt = stmt.where(
            SKU.name.ilike(like)
            | SKU.sku_code.ilike(like)
            | SKU.variant.ilike(like)
            | StockLot.lot_no.ilike(like)
        )
    stmt = stmt.order_by(SKU.name, StockLot.received_date, StockLot.id)
    out: list[dict] = []
    for lot, sku in db.execute(stmt).all():
        out.append(
            {
                "id": lot.id,
                "sku_id": sku.id,
                "sku_code": sku.sku_code,
                "name": sku.name,
                "variant": sku.variant,
                "category": sku.category,
                "lot_no": lot.lot_no,
                "quantity_received": lot.quantity_received,
                "quantity_remaining": lot.quantity_remaining,
                "sold": lot.sold,
                "received_date": lot.received_date,
                "note": lot.note,
                "created_at": lot.created_at,
            }
        )
    return out


def reset_stock(db: Session, company_id: int) -> dict:
    """Start fresh: remove all lots and stock-movement history for a company and
    set every product's On-Hand to 0. Products, prices and MRP are kept."""
    sku_ids = list(
        db.execute(select(SKU.id).where(SKU.company_id == company_id)).scalars().all()
    )
    lots_deleted = 0
    moves_deleted = 0
    if sku_ids:
        r_lots = db.execute(
            sa_delete(StockLot).where(StockLot.company_id == company_id)
        )
        r_moves = db.execute(
            sa_delete(StockMovement).where(StockMovement.sku_id.in_(sku_ids))
        )
        db.execute(update(SKU).where(SKU.company_id == company_id).values(quantity_on_hand=0))
        lots_deleted = int(r_lots.rowcount or 0)
        moves_deleted = int(r_moves.rowcount or 0)
        db.commit()
    return {
        "skus_reset": len(sku_ids),
        "lots_deleted": lots_deleted,
        "movements_deleted": moves_deleted,
    }
