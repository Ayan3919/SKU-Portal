const API_BASE = "http://127.0.0.1:8000/api";
const COMPANY_LOGOS = { shyam: "assets/shyam-logo.png" };

const params = new URLSearchParams(location.search);
const companyId = Number(params.get("company_id"));

let COMPANY = null;
let SKUS = [];

function prettyDateTime(s) {
  const d = s ? new Date(s) : new Date();
  return isNaN(d) ? "" : d.toLocaleString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

async function load() {
  try {
    const companies = await (await fetch(`${API_BASE}/companies`)).json();
    COMPANY = companies.find((c) => c.id === companyId) || { name: "Company" };
    const res = await fetch(`${API_BASE}/skus?company_id=${companyId}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    SKUS = await res.json();
  } catch (err) {
    document.getElementById("sheet").innerHTML =
      `<p class="empty">Could not load stock list: ${err.message}. Is the server running?</p>`;
    return;
  }
  render();
}

/* Products grouped by category, sorted; returns [ [category, rows[]], ... ] */
function groupedByCategory() {
  const groups = new Map();
  for (const s of SKUS) {
    const cat = (s.category && s.category.trim()) || "Other";
    if (!groups.has(cat)) groups.set(cat, []);
    groups.get(cat).push(s);
  }
  return [...groups.keys()].sort((a, b) => a.localeCompare(b)).map((cat) => [
    cat,
    groups.get(cat).sort((a, b) => (a.name + a.variant).localeCompare(b.name + b.variant)),
  ]);
}

function headerBlock(title, metaExtra) {
  const logo = COMPANY_LOGOS[(COMPANY.name || "").trim().toLowerCase()];
  const logoHtml = logo ? `<img src="${logo}" alt="logo" onerror="this.style.display='none'" />` : "";
  return `
    <div class="rpt-header">
      <div class="rpt-brand">
        ${logoHtml}
        <div>
          <h1>${COMPANY.name}</h1>
          <div class="tag">Stock SKU Portal &middot; Manual Stock Register</div>
        </div>
      </div>
      <div class="rpt-meta">
        <div class="rpt-title">${title}</div>
        <div>Printed: ${prettyDateTime()}</div>
      </div>
    </div>
    <div class="meta-row">${metaExtra}</div>`;
}

/* ---------- Layout 1: simple stock register ---------- */
function renderRegister() {
  const colCount = 7;
  let sl = 0;
  const bodyBlocks = groupedByCategory().map(([cat, list]) => {
    const rows = list.map((s) => {
      sl += 1;
      return `
        <tr>
          <td class="c col-sl">${sl}</td>
          <td>${s.name || ""}</td>
          <td class="col-var">${s.variant || ""}</td>
          <td class="col-fill"></td>
          <td class="col-fill"></td>
          <td class="col-fill"></td>
          <td class="col-rem"></td>
        </tr>`;
    }).join("");
    return `<tr class="cat-row"><td colspan="${colCount}">${cat}</td></tr>${rows}`;
  }).join("");

  const blankRows = Array.from({ length: 3 }).map(() => `
    <tr class="blank">
      <td class="c col-sl"></td><td></td><td class="col-var"></td>
      <td class="col-fill"></td><td class="col-fill"></td><td class="col-fill"></td><td class="col-rem"></td>
    </tr>`).join("");

  document.getElementById("sheet").innerHTML = `
    ${headerBlock("Stock Register Sheet", `
      <span>Sheet date: <span class="fill-line">&nbsp;</span></span>
      <span>Prepared by: <span class="fill-line">&nbsp;</span></span>
      <span>Total items: <b>${SKUS.length}</b></span>`)}
    <table class="register">
      <thead>
        <tr>
          <th class="c col-sl">#</th>
          <th>Product</th>
          <th class="col-var">Variant</th>
          <th class="c col-fill">New Stock<br/>Received (+)</th>
          <th class="c col-fill">Stock Out<br/>/ Sold (-)</th>
          <th class="c col-fill">Balance<br/>Left</th>
          <th class="col-rem">Remarks</th>
        </tr>
      </thead>
      <tbody>
        ${bodyBlocks}
        <tr class="cat-row"><td colspan="${colCount}">Other / New products (write below)</td></tr>
        ${blankRows}
      </tbody>
    </table>
    <div class="rpt-foot">
      <div class="sign">Counted by</div>
      <div class="sign">Verified by</div>
    </div>`;

  document.title = `${COMPANY.name} - Stock Register Sheet`;
}

/* ---------- Layout 2: monthly daily-tally grid (days 1-31) ---------- */
function renderDailyTally() {
  const DAYS = 31;
  const dayHeads = Array.from({ length: DAYS }, (_, i) => `<th class="day">${i + 1}</th>`).join("");
  const dayCells = Array.from({ length: DAYS }, () => `<td class="day"></td>`).join("");
  const colCount = 3 + 1 + DAYS + 2; // #, product, variant, opening, days, total, closing

  let sl = 0;
  const bodyBlocks = groupedByCategory().map(([cat, list]) => {
    const rows = list.map((s) => {
      sl += 1;
      return `
        <tr>
          <td class="c col-sl">${sl}</td>
          <td class="col-prod">${s.name || ""}</td>
          <td class="col-var">${s.variant || ""}</td>
          <td class="col-open"></td>
          ${dayCells}
          <td class="col-tot"></td>
          <td class="col-close"></td>
        </tr>`;
    }).join("");
    return `<tr class="cat-row"><td colspan="${colCount}">${cat}</td></tr>${rows}`;
  }).join("");

  document.getElementById("sheet").innerHTML = `
    ${headerBlock("Daily Outgoing Stock Tally", `
      <span>Month: <span class="fill-line">&nbsp;</span></span>
      <span>Year: <span class="fill-line" style="min-width:60px">&nbsp;</span></span>
      <span>Prepared by: <span class="fill-line">&nbsp;</span></span>
      <span>Total items: <b>${SKUS.length}</b></span>`)}
    <p class="hint-line">Write the quantity that went out on each day under that day's number. Opening = stock at month start; Closing = Opening + received − total out.</p>
    <table class="daily">
      <thead>
        <tr>
          <th class="c col-sl">#</th>
          <th class="col-prod">Product</th>
          <th class="col-var">Variant</th>
          <th class="col-open">Open</th>
          ${dayHeads}
          <th class="col-tot">Tot<br/>Out</th>
          <th class="col-close">Close</th>
        </tr>
      </thead>
      <tbody>${bodyBlocks}</tbody>
    </table>
    <div class="rpt-foot">
      <div class="sign">Counted by</div>
      <div class="sign">Verified by</div>
    </div>`;

  document.title = `${COMPANY.name} - Daily Outgoing Tally`;
}

function currentType() {
  return document.getElementById("sheet-type").value;
}

function render() {
  const type = currentType();
  document.body.classList.toggle("daily-mode", type === "daily");
  if (type === "daily") {
    // The 31-day grid needs landscape to fit.
    document.getElementById("orientation").value = "landscape";
    renderDailyTally();
  } else {
    renderRegister();
  }
  applyOrientation();
}

function applyOrientation() {
  const mode = document.getElementById("orientation").value;
  let style = document.getElementById("orient-style");
  if (!style) {
    style = document.createElement("style");
    style.id = "orient-style";
    document.head.appendChild(style);
  }
  const size = mode === "landscape" ? "A4 landscape" : "A4 portrait";
  style.textContent = `@media print { @page { size: ${size}; margin: 8mm; } }`;
  const sheet = document.querySelector(".sheet");
  if (sheet) sheet.style.width = mode === "landscape" ? "297mm" : "210mm";
}

document.getElementById("sheet-type").addEventListener("change", render);
document.getElementById("orientation").addEventListener("change", applyOrientation);

load();
