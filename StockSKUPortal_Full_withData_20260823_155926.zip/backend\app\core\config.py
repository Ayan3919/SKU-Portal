from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

# Project root = .../stock_sku_portal (config.py is at backend/app/core/config.py)
PROJECT_ROOT = Path(__file__).resolve().parents[3]


class Settings(BaseSettings):
    app_name: str = "Stock SKU Portal"
    app_env: str = "development"
    database_url: str = "sqlite:///../data/stock_sku.db"
    cors_origins: str = "*"

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    @property
    def cors_origins_list(self) -> list[str]:
        if self.cors_origins.strip() == "*":
            return ["*"]
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]

    @property
    def resolved_database_url(self) -> str:
        """Anchor relative SQLite paths to the project root so the app and tests
        work regardless of the current working directory."""
        prefix = "sqlite:///"
        if not self.database_url.startswith(prefix):
            return self.database_url

        raw_path = self.database_url[len(prefix):]
        db_path = Path(raw_path)
        if not db_path.is_absolute():
            # Strip leading ../ and re-anchor to the project root
            parts = [p for p in db_path.parts if p != ".."]
            db_path = PROJECT_ROOT.joinpath(*parts)

        db_path.parent.mkdir(parents=True, exist_ok=True)
        return f"{prefix}{db_path}"


settings = Settings()
