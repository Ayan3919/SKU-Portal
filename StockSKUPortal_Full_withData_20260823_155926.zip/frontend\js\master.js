const API_BASE = "http://127.0.0.1:8000/api";

const el = (id) => document.getElementById(id);
const state = { companyId: null, companies: [], lots: [], view: "product" };

const savedCompanyId = Number(localStorage.getItem("selectedCompanyId")) || null;
if (savedCompanyId) state.companyId = savedCompanyId;

const companySelect = el("company-select");
const content = el("master-content");
const listMsg = el("list-msg");

function setListMsg(text, type = "") {
  listMsg.textContent = text;
  listMsg.className = "msg" + (type ? " " + type : "");
}
function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );
}
function prettyDate(d) {
  if (!d) return "";
  const dt = new Date(d);
  return isNaN(dt) ? esc(d) : dt.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}
async function api(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, options);
  if (!res.ok && res.status !== 204) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `HTTP ${res.status}`);
  }
  return res.status === 204 ? null : res.json();
}

const COMPANY_LOGOS = { shyam: "assets/shyam-logo.png" };
function renderLogo() {
  const logo = el("company-logo");
  const c = state.companies.find((x) => x.id === state.companyId);
  const src = c ? COMPANY_LOGOS[c.name.trim().toLowerCase()] : null;
  if (src) { logo.src = src; logo.classList.remove("hidden"); }
  else { logo.classList.add("hidden"); logo.removeAttribute("src"); }
}

async function loadCompanies() {
  try {
    state.companies = await api("/companies");
  } catch (err) {
    setListMsg("Failed to reach API: " + err.message + ". Is the server running?", "error");
    return;
  }
  if (!state.companies.length) {
    companySelect.innerHTML = `<option value="">No companies yet</option>`;
    content.innerHTML = "";
    setListMsg("No companies yet. Create one on the Inventory page first.");
    return;
  }
  companySelect.innerHTML = state.companies.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join("");
  if (!state.companyId || !state.companies.some((c) => c.id === state.companyId)) {
    state.companyId = state.companies[0].id;
  }
  localStorage.setItem("selectedCompanyId", state.companyId);
  companySelect.value = state.companyId;
  await loadLots();
}

async function loadLots() {
  if (!state.companyId) return;
  const search = el("search").value.trim();
  const q = search ? `?search=${encodeURIComponent(search)}` : "";
  try {
    state.lots = await api(`/companies/${state.companyId}/lots${q}`);
    renderStats();
    render();
    setListMsg("");
  } catch (err) {
    setListMsg("Failed to load lots: " + err.message, "error");
  }
}

function renderStats() {
  renderLogo();
  const lots = state.lots;
  const received = lots.reduce((a, l) => a + l.quantity_received, 0);
  const sold = lots.reduce((a, l) => a + l.sold, 0);
  const remaining = lots.reduce((a, l) => a + l.quantity_remaining, 0);
  const lotCount = new Set(lots.map((l) => l.lot_no)).size;
  el("stats").innerHTML = `
    <div class="stat"><span class="stat-num">${lotCount}</span><span class="stat-label">Lots</span></div>
    <div class="stat"><span class="stat-num">${received}</span><span class="stat-label">Total received</span></div>
    <div class="stat"><span class="stat-num">${sold}</span><span class="stat-label">Total sold</span></div>
    <div class="stat ${remaining <= 0 ? "warn" : ""}"><span class="stat-num">${remaining}</span><span class="stat-label">Remaining</span></div>`;
}

function lotRow(l) {
  const depleted = l.quantity_remaining <= 0;
  return `<tr class="${depleted ? "row-warn" : ""}">
      <td>${esc(l.lot_no)}</td>
      <td>${prettyDate(l.received_date)}</td>
      <td class="num">${l.quantity_received}</td>
      <td class="num">${l.sold}</td>
      <td class="num"><strong>${l.quantity_remaining}</strong></td>
    </tr>`;
}

function groupBy(list, keyFn) {
  const map = new Map();
  for (const item of list) {
    const k = keyFn(item);
    if (!map.has(k)) map.set(k, []);
    map.get(k).push(item);
  }
  return map;
}

function subtotal(rows) {
  return {
    received: rows.reduce((a, l) => a + l.quantity_received, 0),
    sold: rows.reduce((a, l) => a + l.sold, 0),
    remaining: rows.reduce((a, l) => a + l.quantity_remaining, 0),
  };
}

function render() {
  if (!state.lots.length) {
    content.innerHTML = `<p class="empty">No lots yet. Use "Stock In" on the Inventory page and enter a Lot No to start tracking.</p>`;
    return;
  }
  content.innerHTML = state.view === "product" ? renderByProduct() : renderByLot();
}

function renderByProduct() {
  const groups = groupBy(state.lots, (l) => l.sku_id);
  const blocks = [];
  for (const [, rows] of groups) {
    const first = rows[0];
    const st = subtotal(rows);
    const title = `${esc(first.name)}${first.variant ? " - " + esc(first.variant) : ""}`;
    blocks.push(`
      <div class="lot-block">
        <h3 class="lot-group-title">${title} <span class="muted-line">(${esc(first.sku_code)})</span></h3>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Lot No</th><th>Received Date</th><th class="num">Received</th><th class="num">Sold</th><th class="num">Remaining</th></tr></thead>
            <tbody>${rows.map(lotRow).join("")}</tbody>
            <tfoot><tr class="subtotal">
              <td colspan="2"><strong>Total</strong></td>
              <td class="num"><strong>${st.received}</strong></td>
              <td class="num"><strong>${st.sold}</strong></td>
              <td class="num"><strong>${st.remaining}</strong></td>
            </tr></tfoot>
          </table>
        </div>
      </div>`);
  }
  return blocks.join("");
}

function renderByLot() {
  const groups = groupBy(state.lots, (l) => l.lot_no);
  const blocks = [];
  for (const [lotNo, rows] of groups) {
    const st = subtotal(rows);
    const body = rows.map((l) => `
      <tr class="${l.quantity_remaining <= 0 ? "row-warn" : ""}">
        <td>${esc(l.name)}${l.variant ? " - " + esc(l.variant) : ""}</td>
        <td>${esc(l.sku_code)}</td>
        <td class="num">${l.quantity_received}</td>
        <td class="num">${l.sold}</td>
        <td class="num"><strong>${l.quantity_remaining}</strong></td>
      </tr>`).join("");
    blocks.push(`
      <div class="lot-block">
        <h3 class="lot-group-title">Lot ${esc(lotNo)} <span class="muted-line">(${prettyDate(rows[0].received_date)})</span></h3>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Product</th><th>SKU</th><th class="num">Received</th><th class="num">Sold</th><th class="num">Remaining</th></tr></thead>
            <tbody>${body}</tbody>
            <tfoot><tr class="subtotal">
              <td colspan="2"><strong>Total</strong></td>
              <td class="num"><strong>${st.received}</strong></td>
              <td class="num"><strong>${st.sold}</strong></td>
              <td class="num"><strong>${st.remaining}</strong></td>
            </tr></tfoot>
          </table>
        </div>
      </div>`);
  }
  return blocks.join("");
}

/* ---------- Controls ---------- */
companySelect.addEventListener("change", async () => {
  state.companyId = Number(companySelect.value);
  localStorage.setItem("selectedCompanyId", state.companyId);
  await loadLots();
});
el("search").addEventListener("input", debounce(loadLots, 250));
el("view-product").addEventListener("click", () => setView("product"));
el("view-lot").addEventListener("click", () => setView("lot"));

function setView(v) {
  state.view = v;
  el("view-product").classList.toggle("active", v === "product");
  el("view-lot").classList.toggle("active", v === "lot");
  render();
}

el("reset-stock-btn").addEventListener("click", async () => {
  if (!state.companyId) return setListMsg("Select a company first.", "error");
  const company = state.companies.find((c) => c.id === state.companyId);
  const name = company ? company.name : "this company";
  const answer = prompt(
    `START FRESH for "${name}":\n` +
    `This clears ALL lots and stock history and sets every product's On-Hand to 0.\n` +
    `Your products, prices and MRP are KEPT. This cannot be undone.\n\nType RESET to confirm:`
  );
  if (answer === null) return;
  if (answer.trim().toUpperCase() !== "RESET") {
    return setListMsg("Cancelled - confirmation text did not match.", "error");
  }
  try {
    const r = await api(`/companies/${state.companyId}/reset-stock`, { method: "POST" });
    setListMsg(`Done. ${r.skus_reset} product(s) reset to 0, ${r.lots_deleted} lot(s) and ${r.movements_deleted} history record(s) cleared.`, "success");
    await loadLots();
  } catch (err) {
    setListMsg("Reset failed: " + err.message, "error");
  }
});

function debounce(fn, ms) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

loadCompanies();
