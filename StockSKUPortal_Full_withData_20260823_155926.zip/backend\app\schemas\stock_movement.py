from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field


class StockChange(BaseModel):
    """Payload for a stock-in or stock-out operation."""

    quantity: int = Field(..., gt=0, examples=[5])
    reference: str | None = Field(None, max_length=128, examples=["INV-1001"])
    note: str | None = Field(None, max_length=500)
    lot_no: str | None = Field(None, max_length=64, examples=["LOT-2024-01"])
    received_date: date | None = Field(None)
    reason: str | None = Field(None, max_length=32, examples=["sale", "correction"])


class StockLotOut(BaseModel):
    """A lot row with its product details, for the master lot screen."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    sku_id: int
    sku_code: str
    name: str
    variant: str | None
    category: str | None
    lot_no: str
    quantity_received: int
    quantity_remaining: int
    sold: int
    received_date: date | None
    note: str | None
    created_at: datetime


class StockMovementOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    sku_id: int
    movement_type: str
    change: int
    balance_after: int
    reference: str | None
    note: str | None
    created_at: datetime
