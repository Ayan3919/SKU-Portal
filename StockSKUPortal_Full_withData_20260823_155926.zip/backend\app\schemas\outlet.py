from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field


class OutletBase(BaseModel):
    name: str = Field(..., max_length=255, examples=["MG Road Counter"])
    phone: str | None = Field(None, max_length=32)
    location: str | None = Field(None, max_length=255)


class OutletCreate(OutletBase):
    pass


class OutletUpdate(BaseModel):
    name: str | None = Field(None, max_length=255)
    phone: str | None = Field(None, max_length=32)
    location: str | None = Field(None, max_length=255)


class DispatchCreate(BaseModel):
    sku_id: int
    quantity: int = Field(..., gt=0)
    unit_price: float | None = Field(None, ge=0, description="Defaults to the SKU's MRP if omitted")
    amount_paid: float = Field(0.0, ge=0)
    note: str | None = Field(None, max_length=500)


class OrderItem(BaseModel):
    """A single product line within a multi-item order."""

    sku_id: int
    quantity: int = Field(..., gt=0)
    unit_price: float | None = Field(None, ge=0, description="Defaults to the SKU's MRP if omitted")


class OrderCreate(BaseModel):
    """Dispatch several products to an outlet in one go."""

    items: list[OrderItem] = Field(..., min_length=1)
    amount_paid: float = Field(0.0, ge=0, description="Optional payment for the whole order")
    note: str | None = Field(None, max_length=500)


class DispatchUpdate(BaseModel):
    """Edit an existing dispatch. Changing quantity adjusts SKU inventory by the difference."""

    quantity: int | None = Field(None, gt=0)
    unit_price: float | None = Field(None, ge=0)
    note: str | None = Field(None, max_length=500)


class DispatchPayment(BaseModel):
    """Record an additional payment against a dispatch line."""

    amount: float = Field(..., gt=0)


class OutletPayment(BaseModel):
    """Record a payment against the whole outlet's pending balance."""

    amount: float = Field(..., gt=0)
    paid_on: date | None = Field(None, description="Date the payment was received (defaults to today)")
    note: str | None = Field(None, max_length=500)


class OutletPaymentResult(BaseModel):
    allocated: float
    leftover: float
    total_pending: float
    total_paid: float


class OutletPaymentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    amount: float
    paid_on: date | None
    note: str | None
    created_at: datetime


class DispatchOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    outlet_id: int
    sku_id: int | None
    item_name: str
    variant: str | None
    quantity: int
    unit_price: float
    buying_price: float
    total_amount: float
    amount_paid: float
    pending_amount: float
    profit: float
    note: str | None
    created_at: datetime
    updated_at: datetime


class OutletOut(OutletBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    company_id: int
    created_at: datetime


class OutletSummary(OutletOut):
    dispatch_count: int
    total_products: int
    total_amount: float
    total_paid: float
    total_pending: float
    total_profit: float
    last_updated: datetime | None


class OutletDetail(OutletSummary):
    company_name: str | None = None
    dispatches: list[DispatchOut]
    payments: list[OutletPaymentOut] = []


class ReportLine(BaseModel):
    outlet_id: int
    outlet_name: str
    location: str | None
    phone: str | None
    item_name: str
    variant: str | None
    quantity: int
    unit_price: float
    total_amount: float
    amount_paid: float
    pending_amount: float
    created_at: datetime


class DispatchReport(BaseModel):
    company_name: str
    generated_at: datetime
    lines: list[ReportLine]


class CollectionRow(BaseModel):
    outlet_id: int
    name: str
    location: str | None
    phone: str | None
    total_amount: float
    total_paid: float
    pending: float
    oldest_unpaid_date: date | None
    days_overdue: int
    last_payment_date: date | None
