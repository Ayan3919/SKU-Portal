from fastapi import APIRouter, Depends, Header, HTTPException, status
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.auth import LoginRequest, LoginResponse, UserOut
from app.services import auth_service

router = APIRouter(prefix="/auth", tags=["auth"])


def _token_from_header(authorization: str | None) -> str | None:
    if authorization and authorization.lower().startswith("bearer "):
        return authorization.split(" ", 1)[1].strip()
    return None


def current_user(authorization: str | None = Header(None), db: Session = Depends(get_db)):
    user = auth_service.get_user_by_token(db, _token_from_header(authorization))
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return user


@router.post("/login", response_model=LoginResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = auth_service.authenticate(db, payload.username, payload.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    token = auth_service.create_session(db, user)
    return {
        "token": token,
        "username": user.username,
        "display_name": user.display_name,
        "role": user.role,
    }


@router.get("/me", response_model=UserOut)
def me(user=Depends(current_user)):
    return user


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(authorization: str | None = Header(None), db: Session = Depends(get_db)):
    auth_service.delete_session(db, _token_from_header(authorization))
