from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.sku import SKU
from app.models.stock_movement import StockMovement


class InsufficientStockError(Exception):
    def __init__(self, available: int, requested: int):
        self.available = available
        self.requested = requested
        super().__init__(
            f"Insufficient stock: {available} on hand, {requested} requested"
        )


def _record(
    db: Session,
    sku: SKU,
    change: int,
    movement_type: str,
    reference: str | None,
    note: str | None,
) -> StockMovement:
    sku.quantity_on_hand += change
    movement = StockMovement(
        sku_id=sku.id,
        movement_type=movement_type,
        change=change,
        balance_after=sku.quantity_on_hand,
        reference=reference,
        note=note,
    )
    db.add(movement)
    db.commit()
    db.refresh(movement)
    db.refresh(sku)
    return movement


def stock_in(db: Session, sku: SKU, quantity: int, reference=None, note=None) -> StockMovement:
    return _record(db, sku, abs(quantity), "in", reference, note)


def stock_out(db: Session, sku: SKU, quantity: int, reference=None, note=None) -> StockMovement:
    qty = abs(quantity)
    if qty > sku.quantity_on_hand:
        raise InsufficientStockError(sku.quantity_on_hand, qty)
    return _record(db, sku, -qty, "out", reference, note)


def list_movements(db: Session, sku_id: int, limit: int = 100) -> list[StockMovement]:
    stmt = (
        select(StockMovement)
        .where(StockMovement.sku_id == sku_id)
        .order_by(StockMovement.created_at.desc(), StockMovement.id.desc())
        .limit(limit)
    )
    return list(db.execute(stmt).scalars().all())
