from datetime import datetime

from sqlalchemy import (
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


class SKU(Base):
    __tablename__ = "skus"
    __table_args__ = (
        UniqueConstraint("company_id", "sku_code", name="uq_company_sku_code"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    company_id: Mapped[int] = mapped_column(
        ForeignKey("companies.id", ondelete="CASCADE"), index=True, nullable=False
    )
    sku_code: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    variant: Mapped[str | None] = mapped_column(String(64), nullable=True)
    category: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    mrp: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    buying_price: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    selling_price: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    quantity_on_hand: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    reorder_level: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    company: Mapped["Company"] = relationship(back_populates="skus")  # noqa: F821
    movements: Mapped[list["StockMovement"]] = relationship(  # noqa: F821
        back_populates="sku", cascade="all, delete-orphan"
    )

    @property
    def needs_reorder(self) -> bool:
        return self.quantity_on_hand <= self.reorder_level

    @property
    def status(self) -> str:
        return "In Stock" if self.quantity_on_hand > 0 else "Out Of Stock"

    @property
    def total_price(self) -> float:
        return round(self.quantity_on_hand * self.buying_price, 2)

    @property
    def total_selling_price(self) -> float:
        """Value of the quantity in stock at the selling price."""
        return round(self.quantity_on_hand * self.selling_price, 2)

    @property
    def unit_profit(self) -> float:
        """Profit per unit. Zero until a selling price is entered."""
        return round(self.selling_price - self.buying_price, 2) if self.selling_price > 0 else 0.0

    @property
    def net_profit(self) -> float:
        """Net profit on the quantity currently in stock."""
        return round(self.unit_profit * self.quantity_on_hand, 2) if self.selling_price > 0 else 0.0
