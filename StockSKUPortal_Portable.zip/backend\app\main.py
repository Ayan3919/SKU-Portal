from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import auth, companies, health, outlets, skus, stock
from app.core.config import settings
from app.db.database import Base, SessionLocal, engine

# Import models so they register with the metadata before create_all
from app.models import company as _company_model  # noqa: F401
from app.models import outlet as _outlet_model  # noqa: F401
from app.models import sku as _sku_model  # noqa: F401
from app.models import stock_movement as _movement_model  # noqa: F401
from app.models import user as _user_model  # noqa: F401
from app.services import auth_service

Base.metadata.create_all(bind=engine)

# Seed default login accounts on first run
with SessionLocal() as _db:
    auth_service.seed_default_users(_db)

app = FastAPI(title=settings.app_name)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, prefix="/api")
app.include_router(auth.router, prefix="/api")
app.include_router(companies.router, prefix="/api")
app.include_router(skus.router, prefix="/api")
app.include_router(stock.router, prefix="/api")
app.include_router(outlets.router, prefix="/api")


@app.get("/")
def root():
    return {"message": f"{settings.app_name} API. See /docs for interactive documentation."}
