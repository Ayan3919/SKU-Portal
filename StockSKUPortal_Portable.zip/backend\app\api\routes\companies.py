from fastapi import APIRouter, Depends, HTTPException, UploadFile, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.company import CompanyCreate, CompanyOut, CompanySummary
from app.services import company_service, import_export_service, sku_service

router = APIRouter(prefix="/companies", tags=["companies"])


def _get_company_or_404(db: Session, company_id: int):
    company = company_service.get_company(db, company_id)
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")
    return company


@router.get("", response_model=list[CompanySummary])
def list_companies(db: Session = Depends(get_db)):
    return [company_service.summarize(db, c) for c in company_service.list_companies(db)]


@router.post("", response_model=CompanyOut, status_code=status.HTTP_201_CREATED)
def create_company(payload: CompanyCreate, db: Session = Depends(get_db)):
    if company_service.get_company_by_name(db, payload.name):
        raise HTTPException(status_code=409, detail=f"Company '{payload.name}' already exists")
    return company_service.create_company(db, payload.name)


@router.get("/{company_id}", response_model=CompanySummary)
def get_company(company_id: int, db: Session = Depends(get_db)):
    return company_service.summarize(db, _get_company_or_404(db, company_id))


@router.delete("/{company_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_company(company_id: int, db: Session = Depends(get_db)):
    company_service.delete_company(db, _get_company_or_404(db, company_id))


@router.post("/{company_id}/import")
async def import_inventory(company_id: int, file: UploadFile, db: Session = Depends(get_db)):
    company = _get_company_or_404(db, company_id)
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")
    result = import_export_service.import_rows(db, company, file.filename or "upload.csv", content)
    return result


@router.get("/{company_id}/export")
def export_inventory(company_id: int, db: Session = Depends(get_db)):
    company = _get_company_or_404(db, company_id)
    skus = sku_service.list_skus(db, company_id, limit=100000)
    data = import_export_service.export_workbook(db, company, skus)
    safe_name = "".join(c if c.isalnum() else "_" for c in company.name)
    headers = {"Content-Disposition": f'attachment; filename="{safe_name}_inventory.xlsx"'}
    return StreamingResponse(
        iter([data]),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers=headers,
    )
