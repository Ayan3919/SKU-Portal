from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.sku import SKUCreate, SKUOut, SKUUpdate
from app.services import company_service, sku_service

router = APIRouter(prefix="/skus", tags=["skus"])


@router.get("", response_model=list[SKUOut])
def list_skus(
    company_id: int = Query(..., description="Company to list SKUs for"),
    search: str | None = None,
    skip: int = 0,
    limit: int = 1000,
    db: Session = Depends(get_db),
):
    return sku_service.list_skus(db, company_id, search=search, skip=skip, limit=limit)


@router.post("", response_model=SKUOut, status_code=status.HTTP_201_CREATED)
def create_sku(
    payload: SKUCreate,
    company_id: int = Query(..., description="Company to create the SKU under"),
    db: Session = Depends(get_db),
):
    if not company_service.get_company(db, company_id):
        raise HTTPException(status_code=404, detail="Company not found")
    code = (payload.sku_code or "").strip()
    if code and sku_service.get_sku_by_code(db, company_id, code):
        raise HTTPException(status_code=409, detail=f"SKU code '{code}' already exists for this company")
    return sku_service.create_sku(db, company_id, payload)


@router.get("/{sku_id}", response_model=SKUOut)
def get_sku(sku_id: int, db: Session = Depends(get_db)):
    sku = sku_service.get_sku(db, sku_id)
    if not sku:
        raise HTTPException(status_code=404, detail="SKU not found")
    return sku


@router.put("/{sku_id}", response_model=SKUOut)
def update_sku(sku_id: int, payload: SKUUpdate, db: Session = Depends(get_db)):
    sku = sku_service.get_sku(db, sku_id)
    if not sku:
        raise HTTPException(status_code=404, detail="SKU not found")
    return sku_service.update_sku(db, sku, payload)


@router.delete("/{sku_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_sku(sku_id: int, db: Session = Depends(get_db)):
    sku = sku_service.get_sku(db, sku_id)
    if not sku:
        raise HTTPException(status_code=404, detail="SKU not found")
    sku_service.delete_sku(db, sku)
