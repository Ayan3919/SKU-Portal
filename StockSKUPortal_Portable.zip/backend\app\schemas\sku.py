from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class SKUBase(BaseModel):
    sku_code: str | None = Field(None, max_length=64, examples=["PLAI-SHAY-3"])
    name: str = Field(..., max_length=255, examples=["PLAIN SHAYAM Cooker"])
    variant: str | None = Field(None, max_length=64, examples=["3"])
    category: str | None = Field(None, max_length=128, examples=["Cooker"])
    mrp: float = Field(0.0, ge=0)
    buying_price: float = Field(0.0, ge=0)
    selling_price: float = Field(0.0, ge=0)
    quantity_on_hand: int = Field(0, ge=0)
    reorder_level: int = Field(0, ge=0)


class SKUCreate(SKUBase):
    pass


class SKUUpdate(BaseModel):
    name: str | None = Field(None, max_length=255)
    variant: str | None = Field(None, max_length=64)
    category: str | None = Field(None, max_length=128)
    mrp: float | None = Field(None, ge=0)
    buying_price: float | None = Field(None, ge=0)
    selling_price: float | None = Field(None, ge=0)
    reorder_level: int | None = Field(None, ge=0)


class SKUOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    company_id: int
    sku_code: str
    name: str
    variant: str | None
    category: str | None
    mrp: float
    buying_price: float
    selling_price: float
    quantity_on_hand: int
    reorder_level: int
    needs_reorder: bool
    status: str
    total_price: float
    total_selling_price: float
    unit_profit: float
    net_profit: float
    opening_qty: int
    dispatched_qty: int
    realized_profit: float
    created_at: datetime
    updated_at: datetime
