from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class StockChange(BaseModel):
    """Payload for a stock-in or stock-out operation."""

    quantity: int = Field(..., gt=0, examples=[5])
    reference: str | None = Field(None, max_length=128, examples=["INV-1001"])
    note: str | None = Field(None, max_length=500)


class StockMovementOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    sku_id: int
    movement_type: str
    change: int
    balance_after: int
    reference: str | None
    note: str | None
    created_at: datetime
