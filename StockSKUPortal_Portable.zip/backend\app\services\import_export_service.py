import csv
import io
import re

from openpyxl import Workbook, load_workbook
from sqlalchemy.orm import Session

from app.models.company import Company
from app.models.sku import SKU
from app.services import stock_service, sku_service

# Accepted header aliases -> canonical field name.
# Headers are lowercased and internal whitespace collapsed before lookup.
COLUMN_ALIASES = {
    "sku": "name",
    "item": "name",
    "name": "name",
    "product": "name",
    "product name": "name",
    "product varient": "variant",
    "product variant": "variant",
    "varient": "variant",
    "variant": "variant",
    "size": "variant",
    "color": "variant",
    "colour": "variant",
    "category": "category",
    "mrp": "mrp",
    "buying price": "buying_price",
    "buying_price": "buying_price",
    "cost": "buying_price",
    "cost price": "buying_price",
    "price": "buying_price",
    "unit price": "buying_price",
    "selling price": "selling_price",
    "selling_price": "selling_price",
    "sell price": "selling_price",
    "sp": "selling_price",
    "qty on hand": "opening_qty",
    "qty": "opening_qty",
    "quantity": "opening_qty",
    "quantity on hand": "opening_qty",
    "quantity_on_hand": "opening_qty",
    "opening_qty": "opening_qty",
    "opening qty": "opening_qty",
    "sku_code": "sku_code",
    "sku code": "sku_code",
    "code": "sku_code",
    "reorder level": "reorder_level",
    "reorder_level": "reorder_level",
    # ignored/computed columns fall through to their normalized name and are unused:
    # "sl.no", "total price", "status", "last updated"
}


def _norm_header(h) -> str:
    key = re.sub(r"\s+", " ", str(h or "").strip().lower())
    return COLUMN_ALIASES.get(key, key)


def _to_int(value, default=0) -> int:
    if value in (None, ""):
        return default
    try:
        return int(float(str(value).replace(",", "").strip()))
    except (ValueError, TypeError):
        return default


def _to_float(value, default=0.0) -> float:
    if value in (None, ""):
        return default
    try:
        return float(str(value).replace(",", "").strip())
    except (ValueError, TypeError):
        return default


def _clean_str(value):
    if value in (None, ""):
        return None
    s = str(value).strip()
    return s or None


def _parse_rows(filename: str, content: bytes) -> list[dict]:
    """Return a list of row dicts keyed by canonical field names."""
    name = (filename or "").lower()
    rows: list[dict] = []

    if name.endswith(".xlsx") or name.endswith(".xlsm"):
        wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
        ws = wb.active
        iterator = ws.iter_rows(values_only=True)
        try:
            header = next(iterator)
        except StopIteration:
            return []
        headers = [_norm_header(h) for h in header]
        for raw in iterator:
            rows.append({headers[i]: raw[i] for i in range(len(headers)) if i < len(raw)})
    else:
        text = content.decode("utf-8-sig", errors="replace")
        reader = csv.reader(io.StringIO(text))
        all_rows = list(reader)
        if not all_rows:
            return []
        headers = [_norm_header(h) for h in all_rows[0]]
        for raw in all_rows[1:]:
            rows.append({headers[i]: raw[i] for i in range(len(headers)) if i < len(raw)})
    return rows


def import_rows(db: Session, company: Company, filename: str, content: bytes) -> dict:
    rows = _parse_rows(filename, content)
    created = 0
    updated = 0
    errors: list[str] = []

    for idx, row in enumerate(rows, start=2):  # row 1 is the header
        name = _clean_str(row.get("name"))
        if not name:
            continue  # skip blank lines silently
        variant = _clean_str(row.get("variant"))
        category = _clean_str(row.get("category"))
        code = str(row.get("sku_code") or "").strip()
        opening_qty = _to_int(row.get("opening_qty"))
        reorder_level = _to_int(row.get("reorder_level"))
        mrp = _to_float(row.get("mrp"))
        buying_price = _to_float(row.get("buying_price"))
        selling_price = _to_float(row.get("selling_price"))

        try:
            existing = None
            if code:
                existing = sku_service.get_sku_by_code(db, company.id, code)
            if existing is None:
                existing = _find_by_name_variant(db, company.id, name, variant)

            if existing:
                existing.name = name
                existing.variant = variant
                existing.category = category
                existing.mrp = mrp
                existing.buying_price = buying_price
                if selling_price:
                    existing.selling_price = selling_price
                existing.reorder_level = reorder_level
                db.commit()
                delta = opening_qty - existing.quantity_on_hand
                if delta != 0:
                    stock_service._record(
                        db, existing, delta, "adjust", "import", "Qty set via import"
                    )
                updated += 1
            else:
                if not code:
                    code = sku_service.generate_sku_code(db, company.id, name, variant)
                sku = SKU(
                    company_id=company.id,
                    sku_code=code,
                    name=name,
                    variant=variant,
                    category=category,
                    mrp=mrp,
                    buying_price=buying_price,
                    selling_price=selling_price,
                    quantity_on_hand=0,
                    reorder_level=reorder_level,
                )
                db.add(sku)
                db.commit()
                db.refresh(sku)
                if opening_qty:
                    stock_service._record(db, sku, opening_qty, "in", "import", "Opening balance")
                created += 1
        except Exception as exc:  # noqa: BLE001
            db.rollback()
            errors.append(f"Row {idx} ({name}): {exc}")

    return {"created": created, "updated": updated, "errors": errors, "total_rows": len(rows)}


def _find_by_name_variant(db: Session, company_id: int, name: str, variant: str | None) -> SKU | None:
    from sqlalchemy import select

    stmt = select(SKU).where(SKU.company_id == company_id, SKU.name == name)
    if variant is None:
        stmt = stmt.where(SKU.variant.is_(None))
    else:
        stmt = stmt.where(SKU.variant == variant)
    return db.execute(stmt).scalar_one_or_none()


def export_workbook(db: Session, company: Company, skus: list[SKU]) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "Inventory"
    headers = [
        "Sl.NO", "SKU", "Product Varient", "Category", "MRP",
        "Buying Price", "Selling Price", "Profit Per Unit",
        "Opening (Received)", "Sold", "Qty On Hand",
        "Total Price (Buying)", "Total Price (Selling)",
        "Realized Profit", "Status", "Last Updated",
    ]
    ws.append(headers)
    for i, s in enumerate(skus, start=1):
        ws.append([
            i, s.name, s.variant or "", s.category or "", s.mrp,
            s.buying_price, s.selling_price, s.unit_profit,
            getattr(s, "opening_qty", s.quantity_on_hand),
            getattr(s, "dispatched_qty", 0), s.quantity_on_hand,
            s.total_price, s.total_selling_price,
            getattr(s, "realized_profit", 0.0), s.status,
            s.updated_at.strftime("%m/%d/%Y") if s.updated_at else "",
        ])

    for column_cells in ws.columns:
        width = max((len(str(c.value)) for c in column_cells if c.value is not None), default=10)
        ws.column_dimensions[column_cells[0].column_letter].width = min(width + 2, 42)

    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()
