@echo off
title Stock SKU Portal - Setup
cd /d "%~dp0backend"

echo ============================================
echo   Stock SKU Portal - First-time Setup
echo ============================================
echo.

REM Check Python is installed and on PATH
python --version >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python was not found.
  echo Please install Python 3.10+ from https://www.python.org/downloads/
  echo During install, TICK "Add python.exe to PATH", then run this file again.
  echo.
  pause
  exit /b 1
)

echo Python found:
python --version
echo.

REM Create the virtual environment if it does not already exist
if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  python -m venv .venv
) else (
  echo Virtual environment already exists - reusing it.
)
echo.

echo Upgrading pip...
.venv\Scripts\python.exe -m pip install --upgrade pip

echo.
echo Installing dependencies (this may take a couple of minutes)...
.venv\Scripts\python.exe -m pip install -r requirements.txt

echo.
echo ============================================
echo   Setup complete!
echo ============================================
echo.
echo You can now start the portal by double-clicking "Start Portal.bat".
echo.
pause
