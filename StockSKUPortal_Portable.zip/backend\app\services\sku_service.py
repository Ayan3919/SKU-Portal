import re

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.outlet import OutletDispatch
from app.models.sku import SKU
from app.schemas.sku import SKUCreate, SKUUpdate


def _dispatch_stats(db: Session, sku_ids: list[int]) -> dict[int, tuple[int, float]]:
    """For each SKU id, total units dispatched to outlets and the realized profit
    (actual price charged minus buying price, at dispatch time)."""
    if not sku_ids:
        return {}
    rows = db.execute(
        select(
            OutletDispatch.sku_id,
            func.coalesce(func.sum(OutletDispatch.quantity), 0),
            func.coalesce(
                func.sum(
                    (OutletDispatch.unit_price - OutletDispatch.buying_price)
                    * OutletDispatch.quantity
                ),
                0.0,
            ),
        )
        .where(OutletDispatch.sku_id.in_(sku_ids))
        .group_by(OutletDispatch.sku_id)
    ).all()
    return {r[0]: (int(r[1] or 0), float(r[2] or 0.0)) for r in rows}


def _attach_stats(sku: SKU, stats: dict[int, tuple[int, float]]) -> SKU:
    """Attach derived Opening / Sold / Realized-profit figures to a SKU instance.
    Closing = quantity_on_hand; Opening = Closing + units dispatched out."""
    dispatched, realized = stats.get(sku.id, (0, 0.0))
    sku.dispatched_qty = dispatched
    sku.realized_profit = round(realized, 2)
    sku.opening_qty = sku.quantity_on_hand + dispatched
    return sku


def list_skus(
    db: Session,
    company_id: int,
    search: str | None = None,
    skip: int = 0,
    limit: int = 100000,
) -> list[SKU]:
    stmt = select(SKU).where(SKU.company_id == company_id)
    if search:
        like = f"%{search.strip()}%"
        stmt = stmt.where(
            SKU.name.ilike(like) | SKU.sku_code.ilike(like) | SKU.variant.ilike(like)
        )
    # Order by id to preserve the row order items were added/imported in
    stmt = stmt.order_by(SKU.id).offset(skip).limit(limit)
    rows = list(db.execute(stmt).scalars().all())
    stats = _dispatch_stats(db, [s.id for s in rows])
    for s in rows:
        _attach_stats(s, stats)
    return rows


def get_sku(db: Session, sku_id: int) -> SKU | None:
    sku = db.get(SKU, sku_id)
    if sku is not None:
        _attach_stats(sku, _dispatch_stats(db, [sku.id]))
    return sku


def get_sku_by_code(db: Session, company_id: int, sku_code: str) -> SKU | None:
    stmt = select(SKU).where(SKU.company_id == company_id, SKU.sku_code == sku_code)
    return db.execute(stmt).scalar_one_or_none()


def _slug(text: str, max_tokens: int = 2) -> str:
    tokens = re.findall(r"[A-Za-z0-9]+", (text or "").upper())
    return "-".join(t[:4] for t in tokens[:max_tokens])


def generate_sku_code(db: Session, company_id: int, name: str, variant: str | None) -> str:
    parts = [p for p in (_slug(name), _slug(variant, 1)) if p]
    base = "-".join(parts) or "SKU"
    candidate = base
    counter = 2
    while get_sku_by_code(db, company_id, candidate):
        candidate = f"{base}-{counter}"
        counter += 1
    return candidate


def create_sku(db: Session, company_id: int, payload: SKUCreate) -> SKU:
    data = payload.model_dump()
    code = (data.get("sku_code") or "").strip()
    if not code:
        code = generate_sku_code(db, company_id, data["name"], data.get("variant"))
    data["sku_code"] = code
    opening_qty = data.pop("quantity_on_hand", 0) or 0
    sku = SKU(company_id=company_id, quantity_on_hand=0, **data)
    db.add(sku)
    db.commit()
    db.refresh(sku)
    if opening_qty:
        # Local import to avoid a circular import at module load time
        from app.services import stock_service

        stock_service._record(db, sku, opening_qty, "in", "opening", "Opening balance")
    return _attach_stats(sku, _dispatch_stats(db, [sku.id]))


def update_sku(db: Session, sku: SKU, payload: SKUUpdate) -> SKU:
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(sku, field, value)
    db.commit()
    db.refresh(sku)
    return _attach_stats(sku, _dispatch_stats(db, [sku.id]))


def delete_sku(db: Session, sku: SKU) -> None:
    db.delete(sku)
    db.commit()
